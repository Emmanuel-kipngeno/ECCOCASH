<!DOCTYPE html>
				<html lang="en-US">
				<head>

					<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>

					<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0"/><meta name='robots' content='noindex, follow' />
<meta name="google" content="nositelinkssearchbox" ><script type="application/ld+json">{"@context":"https://schema.org","@type":"Organization","name":"","url":"https://ecocash.co.zw","logo":"","description":"Ecocash"}</script><meta property="og:url" content="https://ecocash.co.zw" /><meta property="og:site_name" content="Ecocash" /><meta property="og:locale" content="en_US" /><meta property="og:type" content="object" /><meta property="og:description" content="Ecocash" /><meta name="twitter:card" content="summary"/><meta name="twitter:locale" content="en_US"/><meta name="twitter:description" content="Ecocash"/><meta name="twitter:url" content="https://ecocash.co.zw"/><meta name="twitter:site" content="@Ecocash"/>
	<!-- This site is optimized with the Yoast SEO plugin v25.7 - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Page not found - Ecocash</title>
	<meta property="og:locale" content="en_US" />
	<meta property="og:title" content="Page not found - Ecocash" />
	<meta property="og:site_name" content="Ecocash" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://ecocash.co.zw/#website","url":"https://ecocash.co.zw/","name":"Ecocash","description":"Ecocash","potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://ecocash.co.zw/?s={search_term_string}"},"query-input":{"@type":"PropertyValueSpecification","valueRequired":true,"valueName":"search_term_string"}}],"inLanguage":"en-US"}]}</script>
	<!-- / Yoast SEO plugin. -->


<link rel='dns-prefetch' href='//www.googletagmanager.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel="alternate" type="application/rss+xml" title="Ecocash &raquo; Feed" href="https://ecocash.co.zw/feed/" />
<link rel="alternate" type="application/rss+xml" title="Ecocash &raquo; Comments Feed" href="https://ecocash.co.zw/comments/feed/" />
<style id='wp-img-auto-sizes-contain-inline-css'>
img:is([sizes=auto i],[sizes^="auto," i]){contain-intrinsic-size:3000px 1500px}
/*# sourceURL=wp-img-auto-sizes-contain-inline-css */
</style>
<style id='wp-emoji-styles-inline-css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
/*# sourceURL=wp-emoji-styles-inline-css */
</style>
<style id='wp-block-library-inline-css'>
:root{--wp-block-synced-color:#7a00df;--wp-block-synced-color--rgb:122,0,223;--wp-bound-block-color:var(--wp-block-synced-color);--wp-editor-canvas-background:#ddd;--wp-admin-theme-color:#007cba;--wp-admin-theme-color--rgb:0,124,186;--wp-admin-theme-color-darker-10:#006ba1;--wp-admin-theme-color-darker-10--rgb:0,107,160.5;--wp-admin-theme-color-darker-20:#005a87;--wp-admin-theme-color-darker-20--rgb:0,90,135;--wp-admin-border-width-focus:2px}@media (min-resolution:192dpi){:root{--wp-admin-border-width-focus:1.5px}}.wp-element-button{cursor:pointer}:root .has-very-light-gray-background-color{background-color:#eee}:root .has-very-dark-gray-background-color{background-color:#313131}:root .has-very-light-gray-color{color:#eee}:root .has-very-dark-gray-color{color:#313131}:root .has-vivid-green-cyan-to-vivid-cyan-blue-gradient-background{background:linear-gradient(135deg,#00d084,#0693e3)}:root .has-purple-crush-gradient-background{background:linear-gradient(135deg,#34e2e4,#4721fb 50%,#ab1dfe)}:root .has-hazy-dawn-gradient-background{background:linear-gradient(135deg,#faaca8,#dad0ec)}:root .has-subdued-olive-gradient-background{background:linear-gradient(135deg,#fafae1,#67a671)}:root .has-atomic-cream-gradient-background{background:linear-gradient(135deg,#fdd79a,#004a59)}:root .has-nightshade-gradient-background{background:linear-gradient(135deg,#330968,#31cdcf)}:root .has-midnight-gradient-background{background:linear-gradient(135deg,#020381,#2874fc)}:root{--wp--preset--font-size--normal:16px;--wp--preset--font-size--huge:42px}.has-regular-font-size{font-size:1em}.has-larger-font-size{font-size:2.625em}.has-normal-font-size{font-size:var(--wp--preset--font-size--normal)}.has-huge-font-size{font-size:var(--wp--preset--font-size--huge)}.has-text-align-center{text-align:center}.has-text-align-left{text-align:left}.has-text-align-right{text-align:right}.has-fit-text{white-space:nowrap!important}#end-resizable-editor-section{display:none}.aligncenter{clear:both}.items-justified-left{justify-content:flex-start}.items-justified-center{justify-content:center}.items-justified-right{justify-content:flex-end}.items-justified-space-between{justify-content:space-between}.screen-reader-text{border:0;clip-path:inset(50%);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px;word-wrap:normal!important}.screen-reader-text:focus{background-color:#ddd;clip-path:none;color:#444;display:block;font-size:1em;height:auto;left:5px;line-height:normal;padding:15px 23px 14px;text-decoration:none;top:5px;width:auto;z-index:100000}html :where(.has-border-color){border-style:solid}html :where([style*=border-top-color]){border-top-style:solid}html :where([style*=border-right-color]){border-right-style:solid}html :where([style*=border-bottom-color]){border-bottom-style:solid}html :where([style*=border-left-color]){border-left-style:solid}html :where([style*=border-width]){border-style:solid}html :where([style*=border-top-width]){border-top-style:solid}html :where([style*=border-right-width]){border-right-style:solid}html :where([style*=border-bottom-width]){border-bottom-style:solid}html :where([style*=border-left-width]){border-left-style:solid}html :where(img[class*=wp-image-]){height:auto;max-width:100%}:where(figure){margin:0 0 1em}html :where(.is-position-sticky){--wp-admin--admin-bar--position-offset:var(--wp-admin--admin-bar--height,0px)}@media screen and (max-width:600px){html :where(.is-position-sticky){--wp-admin--admin-bar--position-offset:0px}}

/*# sourceURL=wp-block-library-inline-css */
</style>
<style id='classic-theme-styles-inline-css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
/*# sourceURL=/wp-includes/css/classic-themes.min.css */
</style>
<link rel='stylesheet' id='codevz-blocks-css' href='https://ecocash.co.zw/wp-content/themes/ecocash/assets/css/blocks.css?ver=6.9.1' media='all' />
<style id='global-styles-inline-css'>
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgb(6,147,227) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgb(252,185,0) 0%,rgb(255,105,0) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgb(255,105,0) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgb(255, 255, 255), 6px 6px rgb(0, 0, 0);--wp--preset--shadow--crisp: 6px 6px 0px rgb(0, 0, 0);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
/*# sourceURL=global-styles-inline-css */
</style>

<link rel='stylesheet' id='cz-icons-pack-css' href='https://ecocash.co.zw/wp-content/plugins/codevz-plus/admin/fields/codevz_fields/icons/czicons.css?ver=4.9.16' media='all' />
<link rel='stylesheet' id='contact-form-7-css' href='https://ecocash.co.zw/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=6.1' media='all' />
<link rel='stylesheet' id='sr7css-css' href='//ecocash.co.zw/wp-content/plugins/revslider/public/css/sr7.css?ver=6.7.34' media='all' />
<link rel='stylesheet' id='ecocash-calculator-style-css' href='https://ecocash.co.zw/wp-content/plugins/tariff%20calc%20final/assets/css/style.css?ver=2.0' media='all' />
<link rel='stylesheet' id='codevz-css' href='https://ecocash.co.zw/wp-content/themes/ecocash/assets/css/core.css?ver=4.9.16' media='all' />
<link rel='stylesheet' id='codevz-laptop-css' href='https://ecocash.co.zw/wp-content/themes/ecocash/assets/css/core-laptop.css?ver=4.9.16' media='screen and (max-width: 1024px)' />
<link rel='stylesheet' id='codevz-tablet-css' href='https://ecocash.co.zw/wp-content/themes/ecocash/assets/css/core-tablet.css?ver=4.9.16' media='screen and (max-width: 1300px)' />
<link rel='stylesheet' id='codevz-mobile-css' href='https://ecocash.co.zw/wp-content/themes/ecocash/assets/css/core-mobile.css?ver=4.9.16' media='screen and (max-width: 480px)' />
<link rel='stylesheet' id='codevz-404-css' href='https://ecocash.co.zw/wp-content/themes/ecocash/assets/css/404.css?ver=4.9.16' media='all' />
<link rel='stylesheet' id='google-font-poppins-css' href='https://fonts.googleapis.com/css?family=Poppins%3A300%2C400%2C700&#038;ver=6.9.1' media='all' />
<link rel='stylesheet' id='pscrollbar-css' href='https://ecocash.co.zw/wp-content/plugins/quadmenu/assets/frontend/pscrollbar/perfect-scrollbar.min.css?ver=3.2.4' media='all' />
<link rel='stylesheet' id='owlcarousel-css' href='https://ecocash.co.zw/wp-content/plugins/quadmenu/assets/frontend/owlcarousel/owl.carousel.min.css?ver=3.2.4' media='all' />
<link rel='stylesheet' id='quadmenu-normalize-css' href='https://ecocash.co.zw/wp-content/plugins/quadmenu/assets/frontend/css/quadmenu-normalize.css?ver=3.2.4' media='all' />
<link rel='stylesheet' id='quadmenu-widgets-css' href='https://ecocash.co.zw/wp-content/uploads/ecocash-child/quadmenu-widgets.css?ver=1755775888' media='all' />
<link rel='stylesheet' id='quadmenu-css' href='https://ecocash.co.zw/wp-content/plugins/quadmenu/build/frontend/style.css?ver=3.2.4' media='all' />
<link rel='stylesheet' id='quadmenu-locations-css' href='https://ecocash.co.zw/wp-content/uploads/ecocash-child/quadmenu-locations.css?ver=1755775887' media='all' />
<link rel='stylesheet' id='dashicons-css' href='https://ecocash.co.zw/wp-includes/css/dashicons.min.css?ver=6.9.1' media='all' />
<link rel='stylesheet' id='codevz-plus-css' href='https://ecocash.co.zw/wp-content/plugins/codevz-plus/assets/css/codevzplus.css?ver=4.9.16' media='all' />
<link rel='stylesheet' id='codevz-plus-tablet-css' href='https://ecocash.co.zw/wp-content/plugins/codevz-plus/assets/css/codevzplus-tablet.css?ver=4.9.16' media='screen and (max-width: 1300px)' />
<link rel='stylesheet' id='codevz-plus-mobile-css' href='https://ecocash.co.zw/wp-content/plugins/codevz-plus/assets/css/codevzplus-mobile.css?ver=4.9.16' media='screen and (max-width: 480px)' />
<style id='akismet-widget-style-inline-css'>

			.a-stats {
				--akismet-color-mid-green: #357b49;
				--akismet-color-white: #fff;
				--akismet-color-light-grey: #f6f7f7;

				max-width: 350px;
				width: auto;
			}

			.a-stats * {
				all: unset;
				box-sizing: border-box;
			}

			.a-stats strong {
				font-weight: 600;
			}

			.a-stats a.a-stats__link,
			.a-stats a.a-stats__link:visited,
			.a-stats a.a-stats__link:active {
				background: var(--akismet-color-mid-green);
				border: none;
				box-shadow: none;
				border-radius: 8px;
				color: var(--akismet-color-white);
				cursor: pointer;
				display: block;
				font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen-Sans', 'Ubuntu', 'Cantarell', 'Helvetica Neue', sans-serif;
				font-weight: 500;
				padding: 12px;
				text-align: center;
				text-decoration: none;
				transition: all 0.2s ease;
			}

			/* Extra specificity to deal with TwentyTwentyOne focus style */
			.widget .a-stats a.a-stats__link:focus {
				background: var(--akismet-color-mid-green);
				color: var(--akismet-color-white);
				text-decoration: none;
			}

			.a-stats a.a-stats__link:hover {
				filter: brightness(110%);
				box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06), 0 0 2px rgba(0, 0, 0, 0.16);
			}

			.a-stats .count {
				color: var(--akismet-color-white);
				display: block;
				font-size: 1.5em;
				line-height: 1.4;
				padding: 0 13px;
				white-space: nowrap;
			}
		
/*# sourceURL=akismet-widget-style-inline-css */
</style>
<link rel='stylesheet' id='chaty-front-css-css' href='https://ecocash.co.zw/wp-content/plugins/chaty/css/chaty-front.min.css?ver=3.4.61756141129' media='all' />
<link rel='stylesheet' id='xtra-elementor-front-css' href='https://ecocash.co.zw/wp-content/plugins/codevz-plus/assets/css/elementor.css?ver=4.9.16' media='all' />
<link rel='stylesheet' id='font-awesome-shims-css' href='https://ecocash.co.zw/wp-content/plugins/codevz-plus/admin/assets/css/font-awesome/css/v4-shims.min.css?ver=6.4.2' media='all' />
<link rel='stylesheet' id='font-awesome-css' href='https://ecocash.co.zw/wp-content/plugins/codevz-plus/admin/assets/css/font-awesome/css/all.min.css?ver=6.4.2' media='all' />
<script src="//ecocash.co.zw/wp-content/plugins/revslider/public/js/libs/tptools.js?ver=6.7.34" id="tp-tools-js" async data-wp-strategy="async"></script>
<script src="//ecocash.co.zw/wp-content/plugins/revslider/public/js/sr7.js?ver=6.7.34" id="sr7-js" async data-wp-strategy="async"></script>
<script src="https://ecocash.co.zw/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script src="https://ecocash.co.zw/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>

<!-- Google tag (gtag.js) snippet added by Site Kit -->
<!-- Google Analytics snippet added by Site Kit -->
<script src="https://www.googletagmanager.com/gtag/js?id=GT-TX588N4" id="google_gtagjs-js" async></script>
<script id="google_gtagjs-js-after">
window.dataLayer = window.dataLayer || [];function gtag(){dataLayer.push(arguments);}
gtag("set","linker",{"domains":["ecocash.co.zw"]});
gtag("js", new Date());
gtag("set", "developer_id.dZTNiMT", true);
gtag("config", "GT-TX588N4");
 window._googlesitekit = window._googlesitekit || {}; window._googlesitekit.throttledEvents = []; window._googlesitekit.gtagEvent = (name, data) => { var key = JSON.stringify( { name, data } ); if ( !! window._googlesitekit.throttledEvents[ key ] ) { return; } window._googlesitekit.throttledEvents[ key ] = true; setTimeout( () => { delete window._googlesitekit.throttledEvents[ key ]; }, 5 ); gtag( "event", name, { ...data, event_source: "site-kit" } ); }; 
//# sourceURL=google_gtagjs-js-after
</script>
<script></script><link rel="https://api.w.org/" href="https://ecocash.co.zw/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://ecocash.co.zw/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.9.1" />
<meta name="format-detection" content="telephone=no"><meta name="generator" content="Site Kit by Google 1.159.0" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
<meta name="generator" content="Powered by Slider Revolution 6.7.34 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<link rel="icon" href="https://ecocash.co.zw/wp-content/uploads/2025/08/cropped-ecocash_favicon_-32x32.png" sizes="32x32" />
<link rel="icon" href="https://ecocash.co.zw/wp-content/uploads/2025/08/cropped-ecocash_favicon_-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://ecocash.co.zw/wp-content/uploads/2025/08/cropped-ecocash_favicon_-180x180.png" />
<meta name="msapplication-TileImage" content="https://ecocash.co.zw/wp-content/uploads/2025/08/cropped-ecocash_favicon_-270x270.png" />
<style id="codevz-inline-css" data-noptimize>.codevz-404 span{background-image: linear-gradient(#0045a0 0%, transparent 75%)}.admin-bar .cz_fixed_top_border{top:32px}.admin-bar i.offcanvas-close {top: 32px}.admin-bar .offcanvas_area, .admin-bar .hidden_top_bar{margin-top: 32px}.admin-bar .header_5,.admin-bar .onSticky{top: 32px}@media screen and (max-width:1300px) {.admin-bar .header_5,.admin-bar .onSticky,.admin-bar .cz_fixed_top_border,.admin-bar i.offcanvas-close {top: 46px}.admin-bar .onSticky {top: 0}.admin-bar .offcanvas_area,.admin-bar .offcanvas_area,.admin-bar .hidden_top_bar{margin-top:46px;height:calc(100% - 46px);}}

/* Theme color */a:hover, .sf-menu > .cz.current_menu > a, .sf-menu > .cz .cz.current_menu > a,.sf-menu > .current-menu-parent > a,.comment-text .star-rating span {color: #0045a0} 
form button, .button, #edd-purchase-button, .edd-submit, .edd-submit.button.blue, .edd-submit.button.blue:hover, .edd-submit.button.blue:focus, [type=submit].edd-submit, .sf-menu > .cz > a:before,.sf-menu > .cz > a:before,
.post-password-form input[type="submit"], .wpcf7-submit, .submit_user, 
#commentform #submit, .commentlist li.bypostauthor > .comment-body:after,.commentlist li.comment-author-admin > .comment-body:after, 
 .pagination .current, .pagination > b, .pagination a:hover, .page-numbers .current, .page-numbers a:hover, .pagination .next:hover, 
.pagination .prev:hover, input[type=submit], .sticky:before, .commentlist li.comment-author-admin .fn,
input[type=submit],input[type=button],.cz_header_button,.cz_default_portfolio a,
.cz_readmore, .more-link, a.cz_btn, .cz_highlight_1:after, div.cz_btn  {background-color: #0045a0}
.cs_load_more_doing, div.wpcf7 .wpcf7-form .ajax-loader {border-right-color: #0045a0}
input:focus,textarea:focus,select:focus {border-color: #0045a0 !important}
::selection {background-color: #0045a0;color: #fff}
::-moz-selection {background-color: #0045a0;color: #fff}

/* Dynamic  */.widget{background-color:rgba(255,255,255,0.01);margin-bottom:35px;border-style:solid;border-width:1px;border-color:#d8d8d8;border-radius:6px}.widget > .codevz-widget-title, .sidebar_inner .widget_block > div > div > h2{font-size:20px;font-weight:700}.logo > a, .logo > h1, .logo h2{text-transform:uppercase}.header_2{border-style:solid;border-bottom-width:1px;border-color:#cccccc}#menu_header_2 > .cz > a{background-color:#ffffff;padding:6px 15px;margin-right:0px;margin-left:10px}#menu_header_2 > .cz > a:hover,#menu_header_2 > .cz:hover > a,#menu_header_2 > .cz.current_menu > a,#menu_header_2 > .current-menu-parent > a{color:#ffffff}#menu_header_2 > .cz > a:before{width:100%;border-width:0px;border-radius:2px;bottom:0px;left:0px}#menu_header_2 .cz .sub-menu:not(.cz_megamenu_inner_ul),#menu_header_2 .cz_megamenu_inner_ul .cz_megamenu_inner_ul{background-color:#0045a0;padding-top:20px;padding-bottom:20px;margin-top:1px;margin-left:30px;border-radius:2px;box-shadow:0px 9px 20px rgba(0,0,0,0.13)}#menu_header_2 .cz .cz a{font-size:14px;color:#cecece}#menu_header_2 .cz .cz a:hover,#menu_header_2 .cz .cz:hover > a,#menu_header_2 .cz .cz.current_menu > a,#menu_header_2 .cz .current_menu > .current_menu{color:#ffffff}.onSticky{background-color:#ffffff !important}.header_4{border-style:solid;border-width:0 0 1px;border-color:#f4f4f4}#menu_header_4 > .cz > a{color:rgba(0,0,0,0.6)}#menu_header_4 > .cz > a:hover,#menu_header_4 > .cz:hover > a,#menu_header_4 > .cz.current_menu > a,#menu_header_4 > .current-menu-parent > a{color:#0045a0}#menu_header_4 .cz .cz a{color:#606060}#menu_header_4 .cz .cz a:hover,#menu_header_4 .cz .cz:hover > a,#menu_header_4 .cz .cz.current_menu > a,#menu_header_4 .cz .current_menu > .current_menu{color:#3f51b5}.page_title,.header_onthe_cover .page_title{background-color:#0045a0;padding-top:10px;padding-bottom:10px;border-style:solid;border-width:0 0 1px;border-color:#f4f4f4}.page_title .section_title{font-size:24px;color:#ffffff;padding-bottom:10px;padding-top:10px}.breadcrumbs a,.breadcrumbs i{color:#e8e8e8}.breadcrumbs{margin-top:12px;margin-right:10px}.cz_middle_footer{background-color:#0045a0;padding-top:60px;padding-bottom:50px}.footer_widget{color:#ffffff;padding:10px 10px 10px 10px}.cz_middle_footer a{font-size:13px;color:#ffffff;line-height: 2}.cz_middle_footer a:hover{color:#c6c6c6}.footer_2{background-color:#0045a0}i.backtotop{color:#ffffff;background-color:#0045a0;border-style:none;border-width:0px;border-radius:10px}i.fixed_contact{color:#0045a0;margin-right:3px;border-style:none;border-radius:50px 0 0 50px ;box-shadow:0px 0px 10px rgba(0,0,0,0.15)}.footer_widget > .codevz-widget-title, footer .widget_block > div > div > h2{color:#ffffff;font-size:28px;font-weight:100;border-style:solid;border-width:0 0 1px}.woocommerce ul.products li.product a img{border-style:solid;border-color:rgba(0,0,0,0.27);border-radius:2px}.woocommerce ul.products li.product .woocommerce-loop-category__title, .woocommerce ul.products li.product .woocommerce-loop-product__title, .woocommerce ul.products li.product h3,.woocommerce.woo-template-2 ul.products li.product .woocommerce-loop-category__title, .woocommerce.woo-template-2 ul.products li.product .woocommerce-loop-product__title, .woocommerce.woo-template-2 ul.products li.product h3{margin-top:15px}.woocommerce ul.products li.product .star-rating{display:none}.woocommerce ul.products li.product .button.add_to_cart_button, .woocommerce ul.products li.product .button[class*="product_type_"]{font-size:14px;font-weight:400;background-color:#0045a0;border-radius:4px;position:absolute;bottom:100px;left:calc(50% - 75px);opacity:0}.woocommerce span.onsale, .woocommerce ul.products li.product .onsale,.woocommerce.single span.onsale, .woocommerce.single ul.products li.product .onsale{font-size:10px;color:#ffffff;font-weight:400;background-color:#079700;top:10px;left:10px}.woocommerce ul.products li.product .price{font-size:14px;color:#0045a0;background-color:rgba(255,255,255,0.01);top:5px;right:5px}.woocommerce div.product .summary > p.price, .woocommerce div.product .summary > span.price{color:#0045a0;font-weight:700}.tagcloud a:hover, .widget .tagcloud a:hover, .cz_post_cat a:hover, .cz_post_views a:hover{color:#ffffff;background-color:#0045a0}.pagination a, .pagination > b, .pagination span, .page-numbers a, .page-numbers span, .woocommerce nav.woocommerce-pagination ul li a, .woocommerce nav.woocommerce-pagination ul li span{font-size:14px;color:#0045a0;font-weight:700;padding:0px;margin-right:5px;border-style:solid;border-width:1px;border-color:rgba(0,69,160,0.25);border-radius:4px}#menu_header_2 .sub-menu .sub-menu:not(.cz_megamenu_inner_ul){margin-top:-20px;margin-left:11px}.cz-cpt-post .cz_readmore, .cz-cpt-post .more-link{color:rgba(255,255,255,0.8);border-radius:3px}.cz-cpt-post .cz_readmore:hover, .cz-cpt-post .more-link:hover{color:#ffffff;background-color:#0045a0}.cz-cpt-post .cz_default_loop .cz_post_author_avatar img{padding:2px;border-style:solid;border-width:1px;border-color:#cccccc;border-radius:5px;box-shadow:none;width:42px}.cz-cpt-post .cz_default_loop .cz_post_author_name{font-size:14px;color:#000370;font-weight:600}.cz-cpt-post .cz_default_loop .cz_post_date{font-size:12px;font-style:italic}.cz-cpt-post .cz_default_loop .cz_post_title h3{font-size:28px;font-weight:500}#menu_header_2 .cz .cz a .cz_indicator{color:#ffffff}.cz_default_loop.sticky > div{background-color:rgba(167,167,167,0.1);margin-bottom:40px;border-style:solid;border-width:2px;border-color:#000370;border-radius:6px}.cz-cpt-post .cz_default_loop > div{padding-bottom:40px;margin-bottom:40px;border-style:solid}.cz-cpt-post .cz_default_loop .cz_post_meta{border-width:0px 0px 0px 6px;border-color:#0045a0;display:inline-block}#comments > h3,.content.cz_related_posts > h4,.content.cz_author_box > h4,.related.products > h2,.upsells.products > h2,.up-sells.products > h2,.up-sells.products > h2,.woocommerce-page .cart-collaterals .cart_totals > h2,.woocommerce-page #customer_details > div:first-child > div:first-child > h3:first-child,.woocommerce-page .codevz-checkout-details > h3,.woocommerce-page .woocommerce-order-details > h2,.woocommerce-page .woocommerce-customer-details > h2,.woocommerce-page .cart-collaterals .cross-sells > h2{font-size:22px}.next_prev{background-color:rgba(255,255,255,0.01);margin-bottom: 35px;border-style: solid;border-width:1px;border-color:#d8d8d8;border-radius:6px;padding:50px}.next_prev .previous i,.next_prev .next i{color:#000000;border-style:solid;border-width:1px;border-color:#e5e5e5;border-radius:4px}.next_prev .previous:hover i,.next_prev .next:hover i{color:#ffffff;background-color:#0045a0}.next_prev h4{margin-right:8px;margin-left:8px} .content .xtra-post-title,  .content .section_title{font-size:32px}.single .content .xtra-post-title{font-size:32px}form button,.comment-form button,a.cz_btn,div.cz_btn,a.cz_btn_half_to_fill:before,a.cz_btn_half_to_fill_v:before,a.cz_btn_half_to_fill:after,a.cz_btn_half_to_fill_v:after,a.cz_btn_unroll_v:before, a.cz_btn_unroll_h:before,a.cz_btn_fill_up:before,a.cz_btn_fill_down:before,a.cz_btn_fill_left:before,a.cz_btn_fill_right:before,.wpcf7-submit,input[type=submit],input[type=button],.button,.cz_header_button,.woocommerce a.button,.woocommerce input.button,.woocommerce #respond input#submit.alt,.woocommerce a.button.alt,.woocommerce button.button.alt,.woocommerce input.button.alt,.woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button, #edd-purchase-button, .edd-submit, [type=submit].edd-submit, .edd-submit.button.blue,.woocommerce #payment #place_order, .woocommerce-page #payment #place_order,.woocommerce button.button:disabled, .woocommerce button.button:disabled[disabled], .woocommerce a.button.wc-forward,.wp-block-search .wp-block-search__button,.woocommerce-message a.restore-item.button{border-radius:2px}input,textarea,select,.qty,.woocommerce-input-wrapper .select2-selection--single,#add_payment_method table.cart td.actions .coupon .input-text, .woocommerce-cart table.cart td.actions .coupon .input-text, .woocommerce-checkout table.cart td.actions .coupon .input-text{border-radius:2px}.pagination .current, .pagination > b, .pagination a:hover, .page-numbers .current, .page-numbers a:hover, .pagination .next:hover, .pagination .prev:hover, .woocommerce nav.woocommerce-pagination ul li a:focus, .woocommerce nav.woocommerce-pagination ul li a:hover, .woocommerce nav.woocommerce-pagination ul li span.current{color:#ffffff}#menu_header_2 .cz_parent_megamenu > [class^="cz_megamenu_"] > .cz, .cz_parent_megamenu > [class*=" cz_megamenu_"] > .cz{padding-right:10px;padding-left:10px;margin-top:10px;margin-bottom:10px;border-style:solid;border-color:rgba(255,255,255,0.1)}#menu_header_2 .cz .cz h6{color:#ffffff}.cz-cpt-post .cz_post_image, .cz-cpt-post .cz_post_svg{border-radius:4px}.cz-cpt-portfolio .cz_default_loop .cz_post_image, .cz-cpt-portfolio .cz_post_svg{border-radius:4px}.cz-cpt-post .cz_default_loop .cz_post_excerpt{font-size:13px;line-height:24px}.header_1{background-color:#004b95}[class*="cz_tooltip_"] [data-title]:after{font-family:'Poppins'}body, body.rtl, .rtl form{font-family:'Poppins'}body h1{font-family:'Poppins'}body h2{font-family:'Poppins';font-weight:300}body h3{font-family:'Poppins';font-weight:500}body h4{font-family:'Poppins';font-weight:300}body h5{font-family:'Poppins'}body h6{font-family:'Poppins'}

/* Responsive */@media screen and (max-width:1240px){#layout{width:100%!important}#layout.layout_1,#layout.layout_2{width:95%!important}.row{width:90% !important;padding:0}blockquote{padding:20px}footer .elms_center,footer .have_center .elms_left, footer .have_center .elms_center, footer .have_center .elms_right{float:none;display:block;text-align:center;margin:0 auto;flex:unset}}@media screen and (max-width:1300px){}@media screen and (max-width:480px){}</style><script>
	window._tpt			??= {};
	window.SR7			??= {};
	_tpt.R				??= {};
	_tpt.R.fonts		??= {};
	_tpt.R.fonts.customFonts??= {};
	SR7.devMode			=  false;
	SR7.F 				??= {};
	SR7.G				??= {};
	SR7.LIB				??= {};
	SR7.E				??= {};
	SR7.E.gAddons		??= {};
	SR7.E.php 			??= {};
	SR7.E.nonce			= '30fe13694a';
	SR7.E.ajaxurl		= 'https://ecocash.co.zw/wp-admin/admin-ajax.php';
	SR7.E.resturl		= 'https://ecocash.co.zw/wp-json/';
	SR7.E.slug_path		= 'revslider/revslider.php';
	SR7.E.slug			= 'revslider';
	SR7.E.plugin_url	= 'https://ecocash.co.zw/wp-content/plugins/revslider/';
	SR7.E.wp_plugin_url = 'https://ecocash.co.zw/wp-content/plugins/';
	SR7.E.revision		= '6.7.34';
	SR7.E.fontBaseUrl	= '//fonts.googleapis.com/css2?family=';
	SR7.G.breakPoints 	= [1240,1024,778,480];
	SR7.E.modules 		= ['module','page','slide','layer','draw','animate','srtools','canvas','defaults','carousel','navigation','media','modifiers','migration'];
	SR7.E.libs 			= ['WEBGL'];
	SR7.E.css 			= ['csslp','cssbtns','cssfilters','cssnav','cssmedia'];
	SR7.E.resources		= {};
	SR7.E.ytnc			= false;
	SR7.JSON			??= {};
/*! Slider Revolution 7.0 - Page Processor */
!function(){"use strict";window.SR7??={},window._tpt??={},SR7.version="Slider Revolution 6.7.16",_tpt.getMobileZoom=()=>_tpt.is_mobile?document.documentElement.clientWidth/window.innerWidth:1,_tpt.getWinDim=function(t){_tpt.screenHeightWithUrlBar??=window.innerHeight;let e=SR7.F?.modal?.visible&&SR7.M[SR7.F.module.getIdByAlias(SR7.F.modal.requested)];_tpt.scrollBar=window.innerWidth!==document.documentElement.clientWidth||e&&window.innerWidth!==e.c.module.clientWidth,_tpt.winW=_tpt.getMobileZoom()*window.innerWidth-(_tpt.scrollBar||"prepare"==t?_tpt.scrollBarW??_tpt.mesureScrollBar():0),_tpt.winH=_tpt.getMobileZoom()*window.innerHeight,_tpt.winWAll=document.documentElement.clientWidth},_tpt.getResponsiveLevel=function(t,e){SR7.M[e];return _tpt.closestGE(t,_tpt.winWAll)},_tpt.mesureScrollBar=function(){let t=document.createElement("div");return t.className="RSscrollbar-measure",t.style.width="100px",t.style.height="100px",t.style.overflow="scroll",t.style.position="absolute",t.style.top="-9999px",document.body.appendChild(t),_tpt.scrollBarW=t.offsetWidth-t.clientWidth,document.body.removeChild(t),_tpt.scrollBarW},_tpt.loadCSS=async function(t,e,s){return s?_tpt.R.fonts.required[e].status=1:(_tpt.R[e]??={},_tpt.R[e].status=1),new Promise(((i,n)=>{if(_tpt.isStylesheetLoaded(t))s?_tpt.R.fonts.required[e].status=2:_tpt.R[e].status=2,i();else{const o=document.createElement("link");o.rel="stylesheet";let l="text",r="css";o["type"]=l+"/"+r,o.href=t,o.onload=()=>{s?_tpt.R.fonts.required[e].status=2:_tpt.R[e].status=2,i()},o.onerror=()=>{s?_tpt.R.fonts.required[e].status=3:_tpt.R[e].status=3,n(new Error(`Failed to load CSS: ${t}`))},document.head.appendChild(o)}}))},_tpt.addContainer=function(t){const{tag:e="div",id:s,class:i,datas:n,textContent:o,iHTML:l}=t,r=document.createElement(e);if(s&&""!==s&&(r.id=s),i&&""!==i&&(r.className=i),n)for(const[t,e]of Object.entries(n))"style"==t?r.style.cssText=e:r.setAttribute(`data-${t}`,e);return o&&(r.textContent=o),l&&(r.innerHTML=l),r},_tpt.collector=function(){return{fragment:new DocumentFragment,add(t){var e=_tpt.addContainer(t);return this.fragment.appendChild(e),e},append(t){t.appendChild(this.fragment)}}},_tpt.isStylesheetLoaded=function(t){let e=t.split("?")[0];return Array.from(document.querySelectorAll('link[rel="stylesheet"], link[rel="preload"]')).some((t=>t.href.split("?")[0]===e))},_tpt.preloader={requests:new Map,preloaderTemplates:new Map,show:function(t,e){if(!e||!t)return;const{type:s,color:i}=e;if(s<0||"off"==s)return;const n=`preloader_${s}`;let o=this.preloaderTemplates.get(n);o||(o=this.build(s,i),this.preloaderTemplates.set(n,o)),this.requests.has(t)||this.requests.set(t,{count:0});const l=this.requests.get(t);clearTimeout(l.timer),l.count++,1===l.count&&(l.timer=setTimeout((()=>{l.preloaderClone=o.cloneNode(!0),l.anim&&l.anim.kill(),void 0!==_tpt.gsap?l.anim=_tpt.gsap.fromTo(l.preloaderClone,1,{opacity:0},{opacity:1}):l.preloaderClone.classList.add("sr7-fade-in"),t.appendChild(l.preloaderClone)}),150))},hide:function(t){if(!this.requests.has(t))return;const e=this.requests.get(t);e.count--,e.count<0&&(e.count=0),e.anim&&e.anim.kill(),0===e.count&&(clearTimeout(e.timer),e.preloaderClone&&(e.preloaderClone.classList.remove("sr7-fade-in"),e.anim=_tpt.gsap.to(e.preloaderClone,.3,{opacity:0,onComplete:function(){e.preloaderClone.remove()}})))},state:function(t){if(!this.requests.has(t))return!1;return this.requests.get(t).count>0},build:(t,e="#ffffff",s="")=>{if(t<0||"off"===t)return null;const i=parseInt(t);if(t="prlt"+i,isNaN(i))return null;if(_tpt.loadCSS(SR7.E.plugin_url+"public/css/preloaders/t"+i+".css","preloader_"+t),isNaN(i)||i<6){const n=`background-color:${e}`,o=1===i||2==i?n:"",l=3===i||4==i?n:"",r=_tpt.collector();["dot1","dot2","bounce1","bounce2","bounce3"].forEach((t=>r.add({tag:"div",class:t,datas:{style:l}})));const d=_tpt.addContainer({tag:"sr7-prl",class:`${t} ${s}`,datas:{style:o}});return r.append(d),d}{let n={};if(7===i){let t;e.startsWith("#")?(t=e.replace("#",""),t=`rgba(${parseInt(t.substring(0,2),16)}, ${parseInt(t.substring(2,4),16)}, ${parseInt(t.substring(4,6),16)}, `):e.startsWith("rgb")&&(t=e.slice(e.indexOf("(")+1,e.lastIndexOf(")")).split(",").map((t=>t.trim())),t=`rgba(${t[0]}, ${t[1]}, ${t[2]}, `),t&&(n.style=`border-top-color: ${t}0.65); border-bottom-color: ${t}0.15); border-left-color: ${t}0.65); border-right-color: ${t}0.15)`)}else 12===i&&(n.style=`background:${e}`);const o=[10,0,4,2,5,9,0,4,4,2][i-6],l=_tpt.collector(),r=l.add({tag:"div",class:"sr7-prl-inner",datas:n});Array.from({length:o}).forEach((()=>r.appendChild(l.add({tag:"span",datas:{style:`background:${e}`}}))));const d=_tpt.addContainer({tag:"sr7-prl",class:`${t} ${s}`});return l.append(d),d}}},SR7.preLoader={show:(t,e)=>{"off"!==(SR7.M[t]?.settings?.pLoader?.type??"off")&&_tpt.preloader.show(e||SR7.M[t].c.module,SR7.M[t]?.settings?.pLoader??{color:"#fff",type:10})},hide:(t,e)=>{"off"!==(SR7.M[t]?.settings?.pLoader?.type??"off")&&_tpt.preloader.hide(e||SR7.M[t].c.module)},state:(t,e)=>_tpt.preloader.state(e||SR7.M[t].c.module)},_tpt.prepareModuleHeight=function(t){window.SR7.M??={},window.SR7.M[t.id]??={},"ignore"==t.googleFont&&(SR7.E.ignoreGoogleFont=!0);let e=window.SR7.M[t.id];if(null==_tpt.scrollBarW&&_tpt.mesureScrollBar(),e.c??={},e.states??={},e.settings??={},e.settings.size??={},t.fixed&&(e.settings.fixed=!0),e.c.module=document.querySelector("sr7-module#"+t.id),e.c.adjuster=e.c.module.getElementsByTagName("sr7-adjuster")[0],e.c.content=e.c.module.getElementsByTagName("sr7-content")[0],"carousel"==t.type&&(e.c.carousel=e.c.content.getElementsByTagName("sr7-carousel")[0]),null==e.c.module||null==e.c.module)return;t.plType&&t.plColor&&(e.settings.pLoader={type:t.plType,color:t.plColor}),void 0===t.plType||"off"===t.plType||SR7.preLoader.state(t.id)&&SR7.preLoader.state(t.id,e.c.module)||SR7.preLoader.show(t.id,e.c.module),_tpt.winW||_tpt.getWinDim("prepare"),_tpt.getWinDim();let s=""+e.c.module.dataset?.modal;"modal"==s||"true"==s||"undefined"!==s&&"false"!==s||(e.settings.size.fullWidth=t.size.fullWidth,e.LEV??=_tpt.getResponsiveLevel(window.SR7.G.breakPoints,t.id),t.vpt=_tpt.fillArray(t.vpt,5),e.settings.vPort=t.vpt[e.LEV],void 0!==t.el&&"720"==t.el[4]&&t.gh[4]!==t.el[4]&&"960"==t.el[3]&&t.gh[3]!==t.el[3]&&"768"==t.el[2]&&t.gh[2]!==t.el[2]&&delete t.el,e.settings.size.height=null==t.el||null==t.el[e.LEV]||0==t.el[e.LEV]||"auto"==t.el[e.LEV]?_tpt.fillArray(t.gh,5,-1):_tpt.fillArray(t.el,5,-1),e.settings.size.width=_tpt.fillArray(t.gw,5,-1),e.settings.size.minHeight=_tpt.fillArray(t.mh??[0],5,-1),e.cacheSize={fullWidth:e.settings.size?.fullWidth,fullHeight:e.settings.size?.fullHeight},void 0!==t.off&&(t.off?.t&&(e.settings.size.m??={})&&(e.settings.size.m.t=t.off.t),t.off?.b&&(e.settings.size.m??={})&&(e.settings.size.m.b=t.off.b),t.off?.l&&(e.settings.size.p??={})&&(e.settings.size.p.l=t.off.l),t.off?.r&&(e.settings.size.p??={})&&(e.settings.size.p.r=t.off.r),e.offsetPrepared=!0),_tpt.updatePMHeight(t.id,t,!0))},_tpt.updatePMHeight=(t,e,s)=>{let i=SR7.M[t];var n=i.settings.size.fullWidth?_tpt.winW:i.c.module.parentNode.offsetWidth;n=0===n||isNaN(n)?_tpt.winW:n;let o=i.settings.size.width[i.LEV]||i.settings.size.width[i.LEV++]||i.settings.size.width[i.LEV--]||n,l=i.settings.size.height[i.LEV]||i.settings.size.height[i.LEV++]||i.settings.size.height[i.LEV--]||0,r=i.settings.size.minHeight[i.LEV]||i.settings.size.minHeight[i.LEV++]||i.settings.size.minHeight[i.LEV--]||0;if(l="auto"==l?0:l,l=parseInt(l),"carousel"!==e.type&&(n-=parseInt(e.onw??0)||0),i.MP=!i.settings.size.fullWidth&&n<o||_tpt.winW<o?Math.min(1,n/o):1,e.size.fullScreen||e.size.fullHeight){let t=parseInt(e.fho)||0,s=(""+e.fho).indexOf("%")>-1;e.newh=_tpt.winH-(s?_tpt.winH*t/100:t)}else e.newh=i.MP*Math.max(l,r);if(e.newh+=(parseInt(e.onh??0)||0)+(parseInt(e.carousel?.pt)||0)+(parseInt(e.carousel?.pb)||0),void 0!==e.slideduration&&(e.newh=Math.max(e.newh,parseInt(e.slideduration)/3)),e.shdw&&_tpt.buildShadow(e.id,e),i.c.adjuster.style.height=e.newh+"px",i.c.module.style.height=e.newh+"px",i.c.content.style.height=e.newh+"px",i.states.heightPrepared=!0,i.dims??={},i.dims.moduleRect=i.c.module.getBoundingClientRect(),i.c.content.style.left="-"+i.dims.moduleRect.left+"px",!i.settings.size.fullWidth)return s&&requestAnimationFrame((()=>{n!==i.c.module.parentNode.offsetWidth&&_tpt.updatePMHeight(e.id,e)})),void _tpt.bgStyle(e.id,e,window.innerWidth==_tpt.winW,!0);_tpt.bgStyle(e.id,e,window.innerWidth==_tpt.winW,!0),requestAnimationFrame((function(){s&&requestAnimationFrame((()=>{n!==i.c.module.parentNode.offsetWidth&&_tpt.updatePMHeight(e.id,e)}))})),i.earlyResizerFunction||(i.earlyResizerFunction=function(){requestAnimationFrame((function(){_tpt.getWinDim(),_tpt.moduleDefaults(e.id,e),_tpt.updateSlideBg(t,!0)}))},window.addEventListener("resize",i.earlyResizerFunction))},_tpt.buildShadow=function(t,e){let s=SR7.M[t];null==s.c.shadow&&(s.c.shadow=document.createElement("sr7-module-shadow"),s.c.shadow.classList.add("sr7-shdw-"+e.shdw),s.c.content.appendChild(s.c.shadow))},_tpt.bgStyle=async(t,e,s,i,n)=>{const o=SR7.M[t];if((e=e??o.settings).fixed&&!o.c.module.classList.contains("sr7-top-fixed")&&(o.c.module.classList.add("sr7-top-fixed"),o.c.module.style.position="fixed",o.c.module.style.width="100%",o.c.module.style.top="0px",o.c.module.style.left="0px",o.c.module.style.pointerEvents="none",o.c.module.style.zIndex=5e3,o.c.content.style.pointerEvents="none"),null==o.c.bgcanvas){let t=document.createElement("sr7-module-bg"),l=!1;if("string"==typeof e?.bg?.color&&e?.bg?.color.includes("{"))if(_tpt.gradient&&_tpt.gsap)e.bg.color=_tpt.gradient.convert(e.bg.color);else try{let t=JSON.parse(e.bg.color);(t?.orig||t?.string)&&(e.bg.color=JSON.parse(e.bg.color))}catch(t){return}let r="string"==typeof e?.bg?.color?e?.bg?.color||"transparent":e?.bg?.color?.string??e?.bg?.color?.orig??e?.bg?.color?.color??"transparent";if(t.style["background"+(String(r).includes("grad")?"":"Color")]=r,("transparent"!==r||n)&&(l=!0),o.offsetPrepared&&(t.style.visibility="hidden"),e?.bg?.image?.src&&(t.style.backgroundImage=`url(${e?.bg?.image.src})`,t.style.backgroundSize=""==(e.bg.image?.size??"")?"cover":e.bg.image.size,t.style.backgroundPosition=e.bg.image.position,t.style.backgroundRepeat=""==e.bg.image.repeat||null==e.bg.image.repeat?"no-repeat":e.bg.image.repeat,l=!0),!l)return;o.c.bgcanvas=t,e.size.fullWidth?t.style.width=_tpt.winW-(s&&_tpt.winH<document.body.offsetHeight?_tpt.scrollBarW:0)+"px":i&&(t.style.width=o.c.module.offsetWidth+"px"),e.sbt?.use?o.c.content.appendChild(o.c.bgcanvas):o.c.module.appendChild(o.c.bgcanvas)}o.c.bgcanvas.style.height=void 0!==e.newh?e.newh+"px":("carousel"==e.type?o.dims.module.h:o.dims.content.h)+"px",o.c.bgcanvas.style.left=!s&&e.sbt?.use||o.c.bgcanvas.closest("SR7-CONTENT")?"0px":"-"+(o?.dims?.moduleRect?.left??0)+"px"},_tpt.updateSlideBg=function(t,e){const s=SR7.M[t];let i=s.settings;s?.c?.bgcanvas&&(i.size.fullWidth?s.c.bgcanvas.style.width=_tpt.winW-(e&&_tpt.winH<document.body.offsetHeight?_tpt.scrollBarW:0)+"px":preparing&&(s.c.bgcanvas.style.width=s.c.module.offsetWidth+"px"))},_tpt.moduleDefaults=(t,e)=>{let s=SR7.M[t];null!=s&&null!=s.c&&null!=s.c.module&&(s.dims??={},s.dims.moduleRect=s.c.module.getBoundingClientRect(),s.c.content.style.left="-"+s.dims.moduleRect.left+"px",s.c.content.style.width=_tpt.winW-_tpt.scrollBarW+"px","carousel"==e.type&&(s.c.module.style.overflow="visible"),_tpt.bgStyle(t,e,window.innerWidth==_tpt.winW))},_tpt.getOffset=t=>{var e=t.getBoundingClientRect(),s=window.pageXOffset||document.documentElement.scrollLeft,i=window.pageYOffset||document.documentElement.scrollTop;return{top:e.top+i,left:e.left+s}},_tpt.fillArray=function(t,e){let s,i;t=Array.isArray(t)?t:[t];let n=Array(e),o=t.length;for(i=0;i<t.length;i++)n[i+(e-o)]=t[i],null==s&&"#"!==t[i]&&(s=t[i]);for(let t=0;t<e;t++)void 0!==n[t]&&"#"!=n[t]||(n[t]=s),s=n[t];return n},_tpt.closestGE=function(t,e){let s=Number.MAX_VALUE,i=-1;for(let n=0;n<t.length;n++)t[n]-1>=e&&t[n]-1-e<s&&(s=t[n]-1-e,i=n);return++i}}();</script>
		<style id="wp-custom-css">
			

/* =============================================================================
   QUADMENU BASE STYLES
   ============================================================================= */

/* Main menu container */
#quadmenu.quadmenu-default_theme {
    background-color: #fff;
    color: #03183B;
    font-weight: 400;
    font-size: 18px !important;
    font-style: normal;
    letter-spacing: inherit;
    position: relative;
    /* margin-left: 90px; */
}


/* Main menu padding between list items */
/* #quadmenu .quadmenu-navbar-nav li.quadmenu-item .quadmenu-item-content {
    padding: 16px !important;
} */

/* Common styles for all menu items */
#quadmenu.quadmenu-default_theme .quadmenu-navbar-nav > li:not(.quadmenu-item-type-button) > a > .quadmenu-item-content,
#quadmenu.quadmenu-default_theme .quadmenu-navbar-nav > li.quadmenu-item > a, 
#quadmenu.quadmenu-default_theme .quadmenu-navbar-nav > li.quadmenu-item > form,
#quadmenu .quadmenu-navbar-nav li.quadmenu-item > a > .quadmenu-item-content > .quadmenu-text {
    color: #03183B;
    font-weight: 400;
    font-size: 18px !important;
    letter-spacing: inherit;
    text-transform: capitalize;
}

/* Specific overrides for links and forms */
#quadmenu.quadmenu-default_theme .quadmenu-navbar-nav > li.quadmenu-item > a, 
#quadmenu.quadmenu-default_theme .quadmenu-navbar-nav > li.quadmenu-item > form {
    background: #fff !important;
    padding: 10px;
}

/* Text elements need inline-block display */
#quadmenu .quadmenu-navbar-nav li.quadmenu-item > a > .quadmenu-item-content > .quadmenu-text {
    display: inline-block;
}

/* =============================================================================
   MENU ICONS
   ============================================================================= */

#quadmenu.quadmenu-default_theme .quadmenu-navbar-nav > li:not(.quadmenu-item-type-button) > a > .quadmenu-item-content > .quadmenu-icon {
    color: #161515;
    font-size: 25px;
}

/* =============================================================================
   DROPDOWN MENUS
   ============================================================================= */

/* Dropdown container with blue gradient top border */
#quadmenu.quadmenu-is-horizontal .quadmenu-navbar-nav li.quadmenu-item > .quadmenu-dropdown-menu {
    position: absolute;
    top: 100%;
    border-radius: 20px;
    background: linear-gradient(to right, #0066cc, #4da6ff) top/100% 5px no-repeat, #ffffff 0 5px;
}

/* Dropdown menu items */
#quadmenu.quadmenu-default_theme .quadmenu-navbar-nav .quadmenu-dropdown-menu li.quadmenu-item > a > .quadmenu-item-content {
    position: relative;
    overflow: hidden;
    font-size: 18px !important;
    padding-bottom: 10px;
    border-bottom: 2px solid transparent;
    transition: all 0.3s ease;
}

/* Widget items in dropdown */
#quadmenu .quadmenu-navbar-nav li.quadmenu-item .quadmenu-item-widget {
    padding: 10px !important;
    background: none;
    border-style: none;
}

/* =============================================================================
   HOVER EFFECTS & ANIMATIONS
   ============================================================================= */

/* Simple fade-in border bottom effect on dropdown items only */
#quadmenu.quadmenu-default_theme .quadmenu-navbar-nav .quadmenu-dropdown-menu li.quadmenu-item > a > .quadmenu-item-content:hover {
    border-bottom-color: #0066cc;
    background-color: rgba(0, 102, 204, 0.05);
}

/* =============================================================================
   UTILITY CLASSES
   ============================================================================= */

.bg-gradient {
    background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%) !important;
}

/* Survey title styling */
h3.surveyTitle {
    font-size: 28px !important;
}

/* =============================================================================
   RESPONSIVE STYLES
   ============================================================================= */

/* Tablet range: adjust menu item padding */
@media (min-width: 768px) and (max-width: 1300px) {
    #quadmenu .quadmenu-navbar-nav li.quadmenu-item .quadmenu-item-content {
        padding: 10px !important;
    }
}

/* Mobile menu item padding */
#quadmenu .quadmenu-navbar-nav li.quadmenu-item .quadmenu-item-content {
    padding: 6px !important;
}

/* Desktop: hide right header section */
@media (min-width: 1114px) {
    .elms_right.header_4_right {
        display: none !important;
    }
	.menu-header_4-2609{
		display: none !important;
	}
}

/* Mobile: hide center header section */
@media (max-width: 1113px) {
    .elms_center.header_4_center {
        display: none !important;
    }
}







/* Global Site Css */

.box-shadow{
	box-shadow: 10px 10px 6px 1px rgba(56,53,53,0.36);
-webkit-box-shadow: 10px 10px 6px 1px rgba(56,53,53,0.36);
-moz-box-shadow: 10px 10px 6px 1px rgba(56,53,53,0.36);
border-radius: 20px;
}
.glass-effect{

background: rgba(255, 255, 255, 0.24);
border-radius: 20px;
box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
backdrop-filter: blur(8.5px);
-webkit-backdrop-filter: blur(8.5px);
border: 1px solid rgba(255, 255, 255, 0.2);
}

.card-shadow{
	backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.2);
	padding: 3% !important;
     border-radius: 20px;
    box-shadow: -1px 4px 18px rgba(0, 0, 0, 0.1);
border-radius: 20px;
}

.cz_btn{
            padding: 15px 35px !important;
            
            text-decoration: none;
            transition: all 0.3s ease!important;
            backdrop-filter: blur(20px)!important;
            font-weight: 400;
            text-transform: uppercase!important;
            letter-spacing: 1px;
            font-size: 0.9rem;
            border-radius: 50px !important;}

@media (max-width: 1024px) {
    .mobile-center {
        text-align: center !important;
    }


/* =============================================================================
   Hide footer middle row paTablet
   ============================================================================= */

@media (min-width: 768px) and (max-width: 1200px) {
    .vc_row.middle-footer,
    .wpb_row.middle-footer,
    .vc_row-fluid.middle-footer,
    .middle-footer.vc_row,
    .middle-footer.wpb_row,
    .middle-footer.vc_row-fluid {
        display: none !important;
    }
}
	
	
}
h2 {
    text-transform: capitalize !important;
		</style>
		<noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript>
				<link rel='stylesheet' id='js_composer_front-css' href='https://ecocash.co.zw/wp-content/plugins/js_composer/assets/css/js_composer.min.css?ver=8.5' media='all' />
<link rel='stylesheet' id='cz_title-css' href='https://ecocash.co.zw/wp-content/plugins/codevz-plus/wpbakery/assets/css/title.css?ver=4.9.16' media='all' />

</head>

				<body id="intro" class="error404 wp-embed-responsive wp-theme-ecocash wp-child-theme-ecocash-child cz-cpt-post  theme-4.9.16 codevz-plus-4.9.16 clr wpb-js-composer js-comp-ver-8.5 vc_responsive"  data-ajax="https://ecocash.co.zw/wp-admin/admin-ajax.php">

				<div id="layout" class="clr layout_"><div class="inner_layout"><div class="cz_overlay" aria-hidden="true"></div><header id="site_header" class="page_header clr"><div class="header_1 cz_menu_fx_left_to_right"><div class="row elms_row"><div class="clr"><div class="elms_right header_1_right"><div class="cz_elm icon_header_1_right_0 inner_icon_header_1_right_0" style="margin-top:20px;margin-right:2%;margin-bottom:20px;"><a class="elm_icon_text" href="https://ecocash.co.zw/agent-locator"><span class="it_text " style="color:#ffffff;">Agent Locator</span></a></div><div class="cz_elm icon_header_1_right_1 inner_icon_header_1_right_1" style="margin-top:20px;margin-right:2%;margin-bottom:20px;"><a class="elm_icon_text" href="https://ecocash.co.zw/contact-us/"><span class="it_text " style="color:#ffffff;">Help</span></a></div></div></div></div></div><div class="header_2 have_center cz_menu_fx_fade_in"><div class="row elms_row"><div class="clr"><div class="elms_left header_2_left"><div class="cz_elm logo_header_2_left_2 inner_logo_header_2_left_0" style="margin-top:25px;margin-bottom:25px;"><div class="logo_is_img logo"><a href="https://ecocash.co.zw/" title="Ecocash"><img src="data:image/svg+xml,%3Csvg%20xmlns%3D&#39;http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg&#39;%20width=&#39;164&#39;%20height=&#39;55&#39;%20viewBox%3D&#39;0%200%20164%2055&#39;%2F%3E" data-czlz data-src="https://ecocash.co.zw/wp-content/uploads/2025/07/EcoCash_logo.png" alt="Ecocash" width="164" height="55" style="width: 164px"></a></div></div></div><div class="elms_center header_2_center"><div><div class="cz_elm menu_header_2_center_3 inner_menu_header_2_center_0" style="margin-top:3%;margin-right:0px;margin-bottom:2%;margin-left:auto;"><i class="fa fa-bars hide icon_mobile_cz_menu_default cz_mi_32487" style="" aria-label="Menu"><span></span></i><nav id="quadmenu" class="quadmenu-default_theme quadmenu-v3.2.4 quadmenu-align-right quadmenu-divider-hide quadmenu-carets-show quadmenu-background-color quadmenu-mobile-shadow-show quadmenu-dropdown-shadow-show quadmenu-hover-ripple quadmenu-is-embed" data-template="embed" data-theme="default_theme" data-unwrap="0" data-breakpoint="768">
	<div class="quadmenu-container">
	<div id="quadmenu_0" class="quadmenu-navbar-collapse collapsed in">
		<ul class="quadmenu-navbar-nav"><li id="menu-item-253" class="quadmenu-item-253 quadmenu-item quadmenu-item-object-mega quadmenu-item-has-children quadmenu-item-type-mega quadmenu-item-level-0 quadmenu-dropdown quadmenu-has-caret quadmenu-has-title quadmenu-has-link quadmenu-dropdown-right dropdown-maxheight">				<a  href="" class="quadmenu-dropdown-toggle hoverintent">
			<span class="quadmenu-item-content">
											<span class="quadmenu-caret"></span>
										<span class="quadmenu-text  hover t_1000">My EcoCash</span>
																	</span>
		</a>
						<div id="dropdown-253" class="quadmenu_btt t_300 quadmenu-dropdown-menu quadmenu-dropdown-stretch-boxed">
				<ul class="quadmenu-row">
		<li id="menu-item-259" class="quadmenu-item-259 quadmenu-item quadmenu-item-object-column quadmenu-item-has-children quadmenu-item-type-column col-xs-12 col-sm-4">		<div id="dropdown-259" class="">
				<ul>
		<li id="menu-item-1595" class="quadmenu-item-1595 quadmenu-item quadmenu-item-object-page quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-2 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">				<a  href="https://ecocash.co.zw/banking-services/">
			<span class="quadmenu-item-content">
																	<span class="quadmenu-text  hover t_1000">Banking Services</span>
																	</span>
		</a>
				</li><li id="menu-item-1596" class="quadmenu-item-1596 quadmenu-item quadmenu-item-object-page quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-2 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">				<a  href="https://ecocash.co.zw/bill-payments/">
			<span class="quadmenu-item-content">
																	<span class="quadmenu-text  hover t_1000">Bill Payments</span>
																	</span>
		</a>
				</li><li id="menu-item-1597" class="quadmenu-item-1597 quadmenu-item quadmenu-item-object-page quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-2 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">				<a  href="https://ecocash.co.zw/buy-airtime/">
			<span class="quadmenu-item-content">
																	<span class="quadmenu-text  hover t_1000">Buy Airtime</span>
																	</span>
		</a>
				</li><li id="menu-item-2323" class="quadmenu-item-2323 quadmenu-item quadmenu-item-object-page quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-2 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">				<a  href="https://ecocash.co.zw/bureau-de-change/">
			<span class="quadmenu-item-content">
																	<span class="quadmenu-text  hover t_1000">Bureau de Change​</span>
																	</span>
		</a>
				</li><li id="menu-item-1635" class="quadmenu-item-1635 quadmenu-item quadmenu-item-object-page quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-2 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">				<a  href="https://ecocash.co.zw/cash-in/">
			<span class="quadmenu-item-content">
																	<span class="quadmenu-text  hover t_1000">Cash In</span>
																	</span>
		</a>
				</li>		</ul>
	</div>
	</li><li id="menu-item-260" class="quadmenu-item-260 quadmenu-item quadmenu-item-object-column quadmenu-item-has-children quadmenu-item-type-column col-xs-12 col-sm-4">		<div id="dropdown-260" class="">
				<ul>
		<li id="menu-item-2324" class="quadmenu-item-2324 quadmenu-item quadmenu-item-object-page quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-2 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">				<a  href="https://ecocash.co.zw/card-services/">
			<span class="quadmenu-item-content">
																	<span class="quadmenu-text  hover t_1000">Card Services</span>
																	</span>
		</a>
				</li><li id="menu-item-1900" class="quadmenu-item-1900 quadmenu-item quadmenu-item-object-page quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-2 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">				<a  href="https://ecocash.co.zw/cash-out/">
			<span class="quadmenu-item-content">
																	<span class="quadmenu-text  hover t_1000">Cash Out</span>
																	</span>
		</a>
				</li><li id="menu-item-1602" class="quadmenu-item-1602 quadmenu-item quadmenu-item-object-page quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-2 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">				<a  href="https://ecocash.co.zw/ecocash-plus/">
			<span class="quadmenu-item-content">
																	<span class="quadmenu-text  hover t_1000">EcoCash Plus</span>
																	</span>
		</a>
				</li><li id="menu-item-1599" class="quadmenu-item-1599 quadmenu-item quadmenu-item-object-page quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-2 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">				<a  href="https://ecocash.co.zw/junior-wallet/">
			<span class="quadmenu-item-content">
																	<span class="quadmenu-text  hover t_1000">Junior Wallet</span>
																	</span>
		</a>
				</li>		</ul>
	</div>
	</li><li id="menu-item-261" class="quadmenu-item-261 quadmenu-item quadmenu-item-object-column quadmenu-item-has-children quadmenu-item-type-column col-xs-12 col-sm-4">		<div id="dropdown-261" class="">
				<ul>
		<li id="menu-item-2160" class="quadmenu-item-2160 quadmenu-item quadmenu-item-object-page quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-2 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">				<a  href="https://ecocash.co.zw/kashagi-loans/">
			<span class="quadmenu-item-content">
																	<span class="quadmenu-text  hover t_1000">Kashagi Loans</span>
																	</span>
		</a>
				</li><li id="menu-item-2325" class="quadmenu-item-2325 quadmenu-item quadmenu-item-object-page quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-2 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">				<a  href="https://ecocash.co.zw/download/">
			<span class="quadmenu-item-content">
																	<span class="quadmenu-text  hover t_1000">My EcoCash App</span>
																	</span>
		</a>
				</li><li id="menu-item-1601" class="quadmenu-item-1601 quadmenu-item quadmenu-item-object-page quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-2 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">				<a  href="https://ecocash.co.zw/ecocash-send-money/">
			<span class="quadmenu-item-content">
																	<span class="quadmenu-text  hover t_1000">Send Money</span>
																	</span>
		</a>
				</li><li id="menu-item-1600" class="quadmenu-item-1600 quadmenu-item quadmenu-item-object-page quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-2 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">				<a  href="https://ecocash.co.zw/pay-merchant/">
			<span class="quadmenu-item-content">
																	<span class="quadmenu-text  hover t_1000">Pay Merchant</span>
																	</span>
		</a>
				</li>		</ul>
	</div>
	</li>		</ul>
	</div>
	</li><li id="menu-item-254" class="quadmenu-item-254 quadmenu-item quadmenu-item-object-mega quadmenu-item-has-children quadmenu-item-type-mega quadmenu-item-level-0 quadmenu-dropdown quadmenu-has-caret quadmenu-has-title quadmenu-has-link quadmenu-dropdown-right dropdown-maxheight">				<a  href="" class="quadmenu-dropdown-toggle hoverintent">
			<span class="quadmenu-item-content">
											<span class="quadmenu-caret"></span>
										<span class="quadmenu-text  hover t_1000">Business</span>
																	</span>
		</a>
						<div id="dropdown-254" class="quadmenu_btt t_300 quadmenu-dropdown-menu quadmenu-dropdown-stretch-boxed">
				<ul class="quadmenu-row">
		<li id="menu-item-1836" class="quadmenu-item-1836 quadmenu-item quadmenu-item-object-column quadmenu-item-has-children quadmenu-item-type-column col-xs-12 col-sm-6">		<div id="dropdown-1836" class="">
				<ul>
		<li id="menu-item-2164" class="quadmenu-item-2164 quadmenu-item quadmenu-item-object-page quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-2 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">				<a  href="https://ecocash.co.zw/ecocash-dmt-partner/">
			<span class="quadmenu-item-content">
																	<span class="quadmenu-text  hover t_1000">EcoCash DMT Partner​</span>
																	</span>
		</a>
				</li><li id="menu-item-1610" class="quadmenu-item-1610 quadmenu-item quadmenu-item-object-page quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-2 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">				<a  href="https://ecocash.co.zw/merchants/">
			<span class="quadmenu-item-content">
																	<span class="quadmenu-text  hover t_1000">Merchants</span>
																	</span>
		</a>
				</li>		</ul>
	</div>
	</li><li id="menu-item-1837" class="quadmenu-item-1837 quadmenu-item quadmenu-item-object-column quadmenu-item-has-children quadmenu-item-type-column col-xs-12 col-sm-6">		<div id="dropdown-1837" class="">
				<ul>
		<li id="menu-item-1611" class="quadmenu-item-1611 quadmenu-item quadmenu-item-object-page quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-2 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">				<a  href="https://ecocash.co.zw/payroll-and-bulk-payments/">
			<span class="quadmenu-item-content">
																	<span class="quadmenu-text  hover t_1000">Payroll And Bulk Payments​</span>
																	</span>
		</a>
				</li><li id="menu-item-2321" class="quadmenu-item-2321 quadmenu-item quadmenu-item-object-page quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-2 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">				<a  href="https://ecocash.co.zw/tarriff-calculator/">
			<span class="quadmenu-item-content">
																	<span class="quadmenu-text  hover t_1000">Tariff Calculator</span>
																	</span>
		</a>
				</li>		</ul>
	</div>
	</li>		</ul>
	</div>
	</li><li id="menu-item-1616" class="quadmenu-item-1616 quadmenu-item quadmenu-item-object-page quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-0 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">				<a  href="https://ecocash.co.zw/remittances/">
			<span class="quadmenu-item-content">
																	<span class="quadmenu-text  hover t_1000">Remittances</span>
																	</span>
		</a>
				</li><li id="menu-item-1618" class="quadmenu-item-1618 quadmenu-item quadmenu-item-object-page quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-0 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">				<a  href="https://ecocash.co.zw/tarriff-calculator/">
			<span class="quadmenu-item-content">
																	<span class="quadmenu-text  hover t_1000">Tariffs</span>
																	</span>
		</a>
				</li><li id="menu-item-1619" class="quadmenu-item-1619 quadmenu-item quadmenu-item-object-page quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-0 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">				<a  href="https://ecocash.co.zw/about-us/">
			<span class="quadmenu-item-content">
																	<span class="quadmenu-text  hover t_1000">About Us</span>
																	</span>
		</a>
				</li></ul>	</div>
	</div>
</nav><i class="fa czico-198-cancel cz_close_popup xtra-close-icon hide" aria-label="Close"></i></div></div></div><div class="elms_right header_2_right"><div class="cz_elm search_header_2_right_4 inner_search_header_2_right_0" style="margin-top:34px;margin-bottom:34px;margin-left:10px;"><div class="search_with_icon search_style_icon_dropdown"><i class="xtra-search-icon fa fa-search" style="font-size:19px;color:#000000;padding:0px 5px 5px;border-radius:2px;" data-cz-style="" aria-label="Search"></i><i class="fa czico-198-cancel cz_close_popup xtra-close-icon hide" aria-label="Close"></i><div class="outer_search" style="background-color:#ffffff;margin-left:-3px;border-radius:20px;"><div class="search" style="">
					<form method="get" action="https://ecocash.co.zw/" autocomplete="off">

						
						<label id="searchLabel380" class="hidden" for="codevzSearch380">Type a keyword ...</label>

						<input id="codevzSearch380" class="ajax_search_input" aria-labelledby="searchLabel380" name="s" type="text" placeholder="Type a keyword ..." style="" required>

						<button type="submit" aria-label="Search"><i class="fa fa-search" data-xtra-icon="fa fa-search" style="color:#000000;" aria-hidden="true"></i></button>

					</form>

					<div class="ajax_search_results" style="margin-top:15px;border-style:none;border-radius:5px;box-shadow:none;" aria-hidden="true"></div>

					
				</div></div></div></div></div></div></div></div><div class="row clr cz_before_mobile_header"><div data-cz-style='.vc_custom_1756130565506{background-color: #004B95 !important;}#cz_40201 .cz_title_content{font-size:14px;color:#ffffff}#cz_40201 .cz_title_content a{color:#ffffff}@media screen and (max-width:1300px){#cz_54179 .cz_title_content{font-size:14px}}@media screen and (max-width:1300px){#cz_20699 .cz_title_content{font-size:14px}}@media screen and (max-width:480px){#cz_54179 .cz_title_content{font-size:12px}}@media screen and (max-width:480px){#cz_20699 .cz_title_content{font-size:12px}}'><div data-vc-full-width="true" data-vc-full-width-temp="true" data-vc-full-width-init="false" class="vc_row wpb_row vc_row-fluid vc_custom_1756130565506 vc_row-has-fill vc_row-o-content-middle vc_row-flex"><div class="wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner"><div class="wpb_wrapper"></div></div></div><div class="wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner"><div class="wpb_wrapper"><div class="cz_gap clr " style="height: 5px"></div><div id="cz_40201" class="cz_40201 cz_title clr cz_title_pos_inline tac"><div class="cz_title_content"><div class="cz_wpe_content"><p style="text-align: center;"><a href="https://ecocash.co.zw/contact-us/">Contact Us</a>              <a href="https://ecocash.co.zw/agent-locator/"> Agent Locator</a></p>
</div></div></div><div class="cz_gap clr " style="height: 5px"></div></div></div></div><div class="wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner"><div class="wpb_wrapper"></div></div></div></div><div class="vc_row-full-width vc_clearfix"></div></div></div><div class="header_4 have_center"><div class="row elms_row"><div class="clr"><div class="elms_left header_4_left"><div class="cz_elm logo_header_4_left_5 inner_logo_header_4_left_0" style="margin-top:20px;margin-bottom:20px;"><div class="logo_is_img logo"><a href="https://ecocash.co.zw/" title="Ecocash"><img src="data:image/svg+xml,%3Csvg%20xmlns%3D&#39;http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg&#39;%20width=&#39;120&#39;%20height=&#39;41&#39;%20viewBox%3D&#39;0%200%20120%2041&#39;%2F%3E" data-czlz data-src="https://ecocash.co.zw/wp-content/uploads/2025/07/EcoCash_logo.png" alt="Ecocash" width="120" height="41" style="width: 120px"></a></div></div></div><div class="elms_center header_4_center"><div><div class="cz_elm menu_header_4_center_6 inner_menu_header_4_center_0" style="margin-top:20px;margin-bottom:20px;"><i class="fa fa-bars hide icon_mobile_cz_menu_default cz_mi_53167" style="" aria-label="Menu"><span></span></i><ul id="menu_header_4" class="sf-menu clr cz_menu_default" data-indicator="" data-indicator2=""><li id="menu-header_4-1663" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-has-children cz" data-sub-menu=""><a href="https://ecocash.co.zw/" data-title="EcoCash Zimbabwe"><span>EcoCash Zimbabwe</span></a>
<ul class="sub-menu">
<li id="menu-header_4-1664" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/banking-services/" data-title="Banking Services"><span>Banking Services</span></a></li>
<li id="menu-header_4-1665" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/bill-payments/" data-title="Bill Payments"><span>Bill Payments</span></a></li>
<li id="menu-header_4-1666" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/buy-airtime/" data-title="Buy Airtime"><span>Buy Airtime</span></a></li>
<li id="menu-header_4-1667" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/cash-in/" data-title="Cash In"><span>Cash In</span></a></li>
<li id="menu-header_4-2161" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/kashagi-loans/" data-title="Kashagi Loans"><span>Kashagi Loans</span></a></li>
<li id="menu-header_4-1668" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/download/" data-title="My EcoCash App"><span>My EcoCash App</span></a></li>
<li id="menu-header_4-1669" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/junior-wallet/" data-title="Junior Wallet"><span>Junior Wallet</span></a></li>
<li id="menu-header_4-1670" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/pay-merchant/" data-title="Pay Merchant"><span>Pay Merchant</span></a></li>
<li id="menu-header_4-1671" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/ecocash-send-money/" data-title="Send Money"><span>Send Money</span></a></li>
<li id="menu-header_4-1672" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/ecocash-plus/" data-title="EcoCash Plus"><span>EcoCash Plus</span></a></li>
</ul>
</li>
<li id="menu-header_4-1673" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children cz" data-sub-menu=""><a href="#" data-title="Business"><span>Business</span></a>
<ul class="sub-menu">
<li id="menu-header_4-2162" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/bureau-de-change/" data-title="Bureau de Change​"><span>Bureau de Change​</span></a></li>
<li id="menu-header_4-1835" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/card-services/" data-title="Card Services"><span>Card Services</span></a></li>
<li id="menu-header_4-1674" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/download/" data-title="My EcoCash App"><span>My EcoCash App</span></a></li>
<li id="menu-header_4-1675" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/merchants/" data-title="Merchants"><span>Merchants</span></a></li>
<li id="menu-header_4-1676" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/payroll-and-bulk-payments/" data-title="Payroll And Bulk Payments​"><span>Payroll And Bulk Payments​</span></a></li>
</ul>
</li>
<li id="menu-header_4-1679" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/remittances/" data-title="Remittances"><span>Remittances</span></a></li>
<li id="menu-header_4-1677" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children cz" data-sub-menu=""><a href="https://ecocash.co.zw/about-us/" data-title="About Us"><span>About Us</span></a>
<ul class="sub-menu">
<li id="menu-header_4-2010" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/our-story/" data-title="Our Story"><span>Our Story</span></a></li>
</ul>
</li>
<li id="menu-header_4-1680" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/tarriff-calculator/" data-title="Tariffs"><span>Tariffs</span></a></li>
</ul><i class="fa czico-198-cancel cz_close_popup xtra-close-icon hide" aria-label="Close"></i></div></div></div><div class="elms_right header_4_right"><div class="cz_elm menu_header_4_right_7 inner_menu_header_4_right_0" style="margin-top:28px;"><i class="fa fa-bars icon_offcanvas_menu inview_right cz_mi_36912" style="font-size:18px;color:#ffffff;background-color:#0045a0;padding:3px;border-radius:0px;" aria-label="Menu"><span></span></i><i class="fa fa-bars hide icon_mobile_offcanvas_menu inview_right cz_mi_36912" style="font-size:18px;color:#ffffff;background-color:#0045a0;padding:3px;border-radius:0px;" aria-label="Menu"><span></span></i><ul id="menu_header_4" class="sf-menu clr offcanvas_menu inview_right" data-indicator="" data-indicator2=""><li id="menu-header_4-1663" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-has-children cz" data-sub-menu=""><a href="https://ecocash.co.zw/" data-title="EcoCash Zimbabwe"><span>EcoCash Zimbabwe</span></a>
<ul class="sub-menu">
<li id="menu-header_4-1664" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/banking-services/" data-title="Banking Services"><span>Banking Services</span></a></li>
<li id="menu-header_4-1665" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/bill-payments/" data-title="Bill Payments"><span>Bill Payments</span></a></li>
<li id="menu-header_4-1666" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/buy-airtime/" data-title="Buy Airtime"><span>Buy Airtime</span></a></li>
<li id="menu-header_4-1667" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/cash-in/" data-title="Cash In"><span>Cash In</span></a></li>
<li id="menu-header_4-2161" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/kashagi-loans/" data-title="Kashagi Loans"><span>Kashagi Loans</span></a></li>
<li id="menu-header_4-1668" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/download/" data-title="My EcoCash App"><span>My EcoCash App</span></a></li>
<li id="menu-header_4-1669" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/junior-wallet/" data-title="Junior Wallet"><span>Junior Wallet</span></a></li>
<li id="menu-header_4-1670" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/pay-merchant/" data-title="Pay Merchant"><span>Pay Merchant</span></a></li>
<li id="menu-header_4-1671" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/ecocash-send-money/" data-title="Send Money"><span>Send Money</span></a></li>
<li id="menu-header_4-1672" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/ecocash-plus/" data-title="EcoCash Plus"><span>EcoCash Plus</span></a></li>
</ul>
</li>
<li id="menu-header_4-1673" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children cz" data-sub-menu=""><a href="#" data-title="Business"><span>Business</span></a>
<ul class="sub-menu">
<li id="menu-header_4-2162" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/bureau-de-change/" data-title="Bureau de Change​"><span>Bureau de Change​</span></a></li>
<li id="menu-header_4-1835" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/card-services/" data-title="Card Services"><span>Card Services</span></a></li>
<li id="menu-header_4-1674" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/download/" data-title="My EcoCash App"><span>My EcoCash App</span></a></li>
<li id="menu-header_4-1675" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/merchants/" data-title="Merchants"><span>Merchants</span></a></li>
<li id="menu-header_4-1676" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/payroll-and-bulk-payments/" data-title="Payroll And Bulk Payments​"><span>Payroll And Bulk Payments​</span></a></li>
</ul>
</li>
<li id="menu-header_4-1679" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/remittances/" data-title="Remittances"><span>Remittances</span></a></li>
<li id="menu-header_4-1677" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children cz" data-sub-menu=""><a href="https://ecocash.co.zw/about-us/" data-title="About Us"><span>About Us</span></a>
<ul class="sub-menu">
<li id="menu-header_4-2010" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/our-story/" data-title="Our Story"><span>Our Story</span></a></li>
</ul>
</li>
<li id="menu-header_4-1680" class="menu-item menu-item-type-post_type menu-item-object-page cz" data-sub-menu=""><a href="https://ecocash.co.zw/tarriff-calculator/" data-title="Tariffs"><span>Tariffs</span></a></li>
</ul><i class="fa czico-198-cancel cz_close_popup xtra-close-icon hide" aria-label="Close"></i></div></div></div></div></div></header><div class="page_cover xtra-cover-type-title"><div class="page_title" data-title-parallax=""><div class="right_br_full_container clr"><div class="row clr"><div class="lefter"><h2 class="section_title ">404</h2></div><div class="righter"><div class="breadcrumbs clr" itemscope itemtype="https://schema.org/BreadcrumbList"><b itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><a href="https://ecocash.co.zw/" itemprop="item"><span itemprop="name" class="hidden" aria-hidden="true">Home</span><i class="fa fa-home cz_breadcrumbs_home" aria-hidden="true"></i></a><meta itemprop="position" content="1" /></b> <i class="fa fa-angle-right" aria-hidden="true"></i> <b itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem" class="inactive_l"><a class="cz_br_current" href="https://ecocash.co.zw/kashagi-loans/revslider/revslider.php/" onclick="return false;" itemprop="item"><span itemprop="name">404</span></a><meta itemprop="position" content="2" /></b></div></div></div></div></div></div><div id="page_content" class="page_content" role="main"><div class="row clr"><div class="s12 clr"><div class="content clr"><h2 class="codevz-404"><span>404</span><small>Page not found!</small></h2><a class="button" href="https://ecocash.co.zw/">Back to Homepage</a></div></div></div></div><footer id="site_footer" class="page_footer"><div class="row clr"><div data-cz-style='.vc_custom_1752677611673{margin-bottom: 0px !important;}.vc_custom_1752412415911{margin-bottom: 0px !important;}.vc_custom_1752407413723{background-color: #F5F5F5 !important;}.vc_custom_1752408341594{background-color: #F5F5F5 !important;}.vc_custom_1752677740003{margin-bottom: 0px !important;}.vc_custom_1768571644829{margin-bottom: 0px !important;}.vc_custom_1752408351570{border-top-width: 1px !important;border-top-style: solid !important;border-color: #DBDADA !important;}#cz_90041 &gt; div{position:relative;}#cz_87302 a{font-size:14px;color:#ffffff;background-color:#2f2c2c;margin-right:2%;border-radius:50%}#cz_28382 &gt; div{position:relative;display: table;margin:0 auto;}#cz_91276 a{font-size:14px;color:#ffffff;background-color:#2f2c2c;margin-right:2%;border-radius:50%}#cz_67219 .cz_title_content a{color:#0045a0}#cz_67219 .cz_title_content a:hover{color:#e53935}@media screen and (max-width:768px){#cz_22761 small{text-align:center}}'><div data-vc-full-width="true" data-vc-full-width-temp="true" data-vc-full-width-init="false" data-vc-stretch-content="true" class="vc_row wpb_row vc_row-fluid vc_custom_1752677611673 vc_row-no-padding"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner"><div class="wpb_wrapper">
	<div class="wpb_raw_code wpb_raw_html wpb_content_element vc_custom_1752677740003" >
		<div class="wpb_wrapper">
			<style>
/* Disclaimer Button Styles */
.disclaimer-btn {
    position: fixed;
    right: 0;
    top: 50%;
    transform: translateY(-50%);
    background: #dc3545 !important;
    color: white;
    border: none;
    padding: 16px 10px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    border-radius: 12px 0 0 12px;
    box-shadow: 
        0 8px 25px rgba(45, 49, 135, 0.25),
        0 4px 12px rgba(0, 0, 0, 0.12);
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    z-index: 1000;
    writing-mode: vertical-rl;
    text-orientation: mixed;
    letter-spacing: 1.5px;
    min-height: 100px;
    display: flex;
    align-items: center;
    justify-content: center;
    text-shadow: 0 1px 3px rgba(0, 0, 0, 0.3);
    -webkit-tap-highlight-color: transparent;
    user-select: none;
}

.disclaimer-btn:hover,
.disclaimer-btn:focus {
    background: #ffffff !important;
    color: #dc3545;
    /*background: linear-gradient(135deg, #1e40af 0%, #3b82f6 30%, #60a5fa 70%, #E9222F 100%) !important;*/
    transform: translateY(-50%) translateX(-4px);
    box-shadow: 
        0 12px 35px rgba(45, 49, 135, 0.3),
        0 6px 16px rgba(0, 0, 0, 0.15);
    outline: none;
}

.disclaimer-btn:active {
    transform: translateY(-50%) translateX(-2px) scale(0.98);
}

/* Overlay Styles */
.disclaimer-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.6);
    backdrop-filter: blur(4px);
    -webkit-backdrop-filter: blur(4px);
    z-index: 1001;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    pointer-events: none;
}

.disclaimer-overlay.active {
    opacity: 1;
    visibility: visible;
    pointer-events: all;
}

/* Modal Styles */
.disclaimer-modal {
    position: fixed;
    background: #ffffff;
    border-radius: 20px 20px 0 0;
    padding: 32px 24px 24px 24px;
    overflow-y: auto;
    box-shadow: 0 -8px 40px rgba(0, 0, 0, 0.25);
    transform: translateY(100%);
    transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    display: flex;
    flex-direction: column;
    -webkit-overflow-scrolling: touch;
}

.disclaimer-overlay.active .disclaimer-modal {
    transform: translateY(0);
}

/* Desktop Modal Positioning */
@media (min-width: 769px) {
    .disclaimer-modal {
        top: 50%;
        right: 0;
        width: 650px;
        max-height: 80vh;
        border-radius: 15px 0 0 15px;
        border-left: 4px solid #1e40af;
        padding: 60px 50px 40px 50px;
        transform: translateX(100%) translateY(-50%);
    }

    .disclaimer-overlay.active .disclaimer-modal {
        transform: translateX(0) translateY(-50%);
    }
}

/* Mobile Modal Positioning */
@media (max-width: 768px) {
    .disclaimer-modal {
        bottom: 0;
        left: 0;
        right: 0;
        width: 100%;
        max-height: 85vh;
        border-top: 4px solid #1e40af;
    }

    .disclaimer-btn {
        padding: 12px 8px;
        font-size: 11px;
        min-height: 80px;
        border-radius: 8px 0 0 8px;
    }
}

/* Extra small screens */
@media (max-width: 480px) {
    .disclaimer-modal {
        max-height: 90vh;
        padding: 24px 20px 20px 20px;
    }

    .disclaimer-btn {
        padding: 10px 6px;
        font-size: 10px;
        min-height: 70px;
        letter-spacing: 1px;
    }
}

/* Modal Handle for Mobile */
.modal-handle {
    display: none;
    width: 40px;
    height: 4px;
    background: #ddd;
    border-radius: 2px;
    margin: 0 auto 20px auto;
    flex-shrink: 0;
}

@media (max-width: 768px) {
    .modal-handle {
        display: block;
    }
}

.disclaimer-title {
    color: #dc3545;
    font-size: 28px;
    font-weight: 700;
    text-align: center;
    margin-bottom: 24px;
    text-transform: uppercase;
    letter-spacing: 2px;
    animation: warningPulse 2s ease-in-out infinite;
    text-shadow: 0 2px 4px rgba(220, 53, 69, 0.3);
    flex-shrink: 0;
}

@media (max-width: 768px) {
    .disclaimer-title {
        font-size: 22px;
        margin-bottom: 20px;
        letter-spacing: 1px;
    }
}

@media (max-width: 480px) {
    .disclaimer-title {
        font-size: 20px;
        margin-bottom: 16px;
    }
}

@keyframes warningPulse {
    0%, 100% {
        transform: scale(1);
        color: #dc3545;
    }
    50% {
        transform: scale(1.03);
        color: #e74c3c;
        text-shadow: 0 4px 8px rgba(220, 53, 69, 0.5);
    }
}

.disclaimer-content {
    color: #444;
    font-size: 16px;
    line-height: 1.6;
    text-align: left;
    margin-bottom: 20px;
    flex: 1;
    overflow-y: auto;
    
}

@media (max-width: 768px) {
    .disclaimer-content {
        font-size: 15px;
        line-height: 1.5;
        margin-bottom: 16px;
    }
}

@media (max-width: 480px) {
    .disclaimer-content {
        font-size: 14px;
    }
}

.disclaimer-content p {
    margin-bottom: 16px;
}

.disclaimer-content p:last-child {
    
    color: #222;
    margin-bottom: 0;
    margin-right:20px;
}

/* Close Button Styles */
.close-btn {
    position: absolute;
    top: 16px;
    left: 16px;
    background: #f8f9fa;
    border: 2px solid #e9ecef;
    font-size: 20px;
    color: #666;
    cursor: pointer;
    width: 44px;
    height: 44px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    transition: all 0.3s ease;
    -webkit-tap-highlight-color: transparent;
    user-select: none;
    flex-shrink: 0;
}

.close-btn:hover,
.close-btn:focus {
    background: #e9ecef;
    color: #333;
    border-color: #ddd;
    transform: scale(1.05);
    outline: none;
}

.close-btn:active {
    transform: scale(0.95);
    background: #dee2e6;
}

.close-btn::before {
    content: "×";
    font-weight: bold;
    line-height: 1;
}

@media (max-width: 768px) {
    .close-btn {
        top: 12px;
        left: 12px;
        width: 40px;
        height: 40px;
        font-size: 18px;
    }
}

@media (max-width: 480px) {
    .close-btn {
        width: 36px;
        height: 36px;
        font-size: 16px;
    }
}

/* Touch improvements */
@media (hover: none) and (pointer: coarse) {
    .disclaimer-btn:hover {
        background: #dc3545 !important;
        transform: translateY(-50%);
        box-shadow: 
            0 8px 25px rgba(45, 49, 135, 0.25),
            0 4px 12px rgba(0, 0, 0, 0.12);
    }

    .close-btn:hover {
        background: #f8f9fa;
        color: #666;
        border-color: #e9ecef;
        transform: none;
    }
}

/* Safe area handling for newer mobile devices */
@supports (padding: max(0px)) {
    @media (max-width: 768px) {
        .disclaimer-modal {
            padding-bottom: max(24px, env(safe-area-inset-bottom));
        }
    }
}
</style>

<!-- Disclaimer Button -->
<button class="disclaimer-btn" id="disclaimerBtn" aria-label="Open Disclaimer">
    Important Notice
</button>

<!-- Disclaimer Overlay -->
<div class="disclaimer-overlay" id="disclaimerOverlay" role="dialog" aria-modal="true" aria-labelledby="disclaimerTitle">
    <div class="disclaimer-modal">
        <div class="modal-handle"></div>
        
        <button class="close-btn" id="closeBtn" aria-label="Close Disclaimer"></button>
        
        <h2 class="disclaimer-title" id="disclaimerTitle">Warning</h2>
        
        <div class="disclaimer-content">
            <p>It has come to our attention that there are people who are approaching potential investors, as well as suppliers, claiming to be supported by EcoCash. Please be advised that EcoCash Zimbabwe is not an investment company and has never provided Venture Capital Funding, or partnered with any business, including start-up ventures. We do not provide loans and have never done so. Furthermore, we do not accept proposals for partnership in any capacity. If you or anyone you know has been approached by someone purporting to be in partnership with EcoCash, please contact our Legal Department or Law Enforcement, as appropriate. EcoCash does not accept claims by anyone who has been defrauded by such people.</p>
               
               
        </div>
    </div>
</div>

<script>
// Enhanced Disclaimer Button Functionality with Mobile Optimizations
document.addEventListener('DOMContentLoaded', function() {
    // Get elements
    const disclaimerBtn = document.getElementById('disclaimerBtn');
    const disclaimerOverlay = document.getElementById('disclaimerOverlay');
    const disclaimerModal = disclaimerOverlay.querySelector('.disclaimer-modal');
    const closeBtn = document.getElementById('closeBtn');
    
    // Check if elements exist before adding event listeners
    if (disclaimerBtn && disclaimerOverlay && closeBtn) {
        
        // Prevent body scroll when modal is open
        function preventBodyScroll(prevent) {
            if (prevent) {
                document.body.style.overflow = 'hidden';
                document.body.style.position = 'fixed';
                document.body.style.width = '100%';
            } else {
                document.body.style.overflow = '';
                document.body.style.position = '';
                document.body.style.width = '';
            }
        }
        
        // Open disclaimer
        disclaimerBtn.addEventListener('click', function() {
            disclaimerOverlay.classList.add('active');
            preventBodyScroll(true);
            
            // Focus trap for accessibility
            setTimeout(() => {
                closeBtn.focus();
            }, 300);
        });
        
        // Close disclaimer function
        function closeDisclaimer() {
            disclaimerOverlay.classList.remove('active');
            preventBodyScroll(false);
            disclaimerBtn.focus(); // Return focus to trigger button
        }
        
        // Close button click
        closeBtn.addEventListener('click', closeDisclaimer);
        
        // Close when clicking outside the modal (not on mobile for better UX)
        disclaimerOverlay.addEventListener('click', function(e) {
            if (e.target === disclaimerOverlay && window.innerWidth > 768) {
                closeDisclaimer();
            }
        });
        
        // Enhanced touch handling for mobile swipe-to-close
        let startY = 0;
        let currentY = 0;
        let isDragging = false;
        
        // Touch start
        disclaimerModal.addEventListener('touchstart', function(e) {
            if (window.innerWidth <= 768 && disclaimerModal.scrollTop === 0) {
                startY = e.touches[0].clientY;
                isDragging = true;
            }
        }, { passive: true });
        
        // Touch move
        disclaimerModal.addEventListener('touchmove', function(e) {
            if (!isDragging || window.innerWidth > 768) return;
            
            currentY = e.touches[0].clientY;
            const deltaY = currentY - startY;
            
            // Only allow downward swipe when at top of scroll
            if (deltaY > 0 && disclaimerModal.scrollTop === 0) {
                const progress = Math.min(deltaY / 200, 1);
                disclaimerModal.style.transform = `translateY(${deltaY * 0.5}px)`;
                disclaimerOverlay.style.opacity = 1 - (progress * 0.5);
            }
        }, { passive: true });
        
        // Touch end
        disclaimerModal.addEventListener('touchend', function(e) {
            if (!isDragging || window.innerWidth > 768) return;
            
            const deltaY = currentY - startY;
            
            // Close if swiped down more than 100px
            if (deltaY > 100) {
                closeDisclaimer();
            } else {
                // Reset position
                disclaimerModal.style.transform = '';
                disclaimerOverlay.style.opacity = '';
            }
            
            isDragging = false;
        }, { passive: true });
        
        // Close with Escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && disclaimerOverlay.classList.contains('active')) {
                closeDisclaimer();
            }
        });
        
        // Handle orientation change
        window.addEventListener('orientationchange', function() {
            setTimeout(() => {
                if (disclaimerOverlay.classList.contains('active')) {
                    // Recalculate modal position if needed
                    disclaimerModal.style.transform = '';
                }
            }, 200);
        });
        
        // Handle window resize
        let resizeTimeout;
        window.addEventListener('resize', function() {
            clearTimeout(resizeTimeout);
            resizeTimeout = setTimeout(() => {
                if (disclaimerOverlay.classList.contains('active')) {
                    disclaimerModal.style.transform = '';
                    disclaimerOverlay.style.opacity = '';
                }
            }, 250);
        });
    }
});
</script>
		</div>
	</div>
</div></div></div></div><div class="vc_row-full-width vc_clearfix"></div><div data-vc-full-width="true" data-vc-full-width-temp="true" data-vc-full-width-init="false" data-vc-stretch-content="true" class="vc_row wpb_row vc_row-fluid vc_custom_1752412415911 vc_row-no-padding"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner"><div class="wpb_wrapper">
	<div class="wpb_raw_code wpb_raw_html wpb_content_element vc_custom_1768571644829" >
		<div class="wpb_wrapper">
			<!-- CSS Styles -->
<style>
.footer-download-section {
    position: relative;
    width: 100%;
    min-height: 400px;
    /*background: linear-gradient(90deg, #0042ff 0%, #26b0da 100%);*/
    background:#007cff;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
    padding: 60px 20px;
}

/* Video Background */
.footer-video-background {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: 1;
    opacity: 0;
    transition: opacity 0.5s ease;
}

.footer-video-background.active {
    opacity: 1;
}

.footer-video-background video {
    width: 50%;
    height: 100%;
    object-fit: cover;
    margin-left: auto;
    display: block;
}

/* Fallback background */
.footer-video-placeholder {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    /*background: linear-gradient(90deg, #0478fc 0%, #26b0da 100%);*/
    z-index: 0;
}

/* Flowing Light Streaks */
.footer-light-streaks {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: 2;
    pointer-events: none;
    overflow: hidden;
}

.footer-light-streaks::before {
    content: '';
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: linear-gradient(45deg, transparent 40%, rgba(0, 0, 0, 0.15) 50%, transparent 60%);
    animation: footerFlowingLights 8s linear infinite;
}

.footer-light-streaks::after {
    content: '';
    position: absolute;
    top: -50%;
    right: -50%;
    width: 200%;
    height: 200%;
    background: linear-gradient(-45deg, transparent 40%, rgba(0, 0, 0, 0.1) 50%, transparent 60%);
    animation: footerFlowingLights 12s linear infinite reverse;
}

@keyframes footerFlowingLights {
    0% { transform: translateX(-100%) translateY(-100%) rotate(45deg); }
    100% { transform: translateX(100%) translateY(100%) rotate(45deg); }
}

/* Dark Overlay */
.footer-dark-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.3);
    z-index: 3;
}

/* Main Content Container */
.footer-content-wrapper {
    position: relative;
    z-index: 4;
    max-width: 1200px;
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 40px;
}

/* Glassmorphism Card */
.footer-download-card {
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.2);
    border-radius: 20px;
    padding: 40px;
    flex: 1;
    max-width: 700px;
}

.footer-download-card h2 {
    font-size: 2.5rem;
    color: white;
    margin-bottom: 10px;
    font-weight: 300;
    line-height: 1.2;
}

.footer-download-card p {
    color: rgba(255, 255, 255, 0.9);
    font-size: 1.1rem;
    margin-bottom: 30px;
    line-height: 1.6;
}

.footer-download-card p strong {
    font-weight: 600;
}

/* Download Options */
.footer-download-options {
    display: flex;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
}

.footer-store-buttons {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
}

.footer-store-btn {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 8px 16px;
    background: rgba(255, 255, 255, 0.2);
    border: 1px solid rgba(255, 255, 255, 0.4);
    border-radius: 12px;
    color: white;
    text-decoration: none;
    transition: all 0.3s ease;
    font-size: 0.85rem;
    font-weight: 500;
    min-height: 44px;
}

.footer-store-btn:hover {
    background: rgba(255, 255, 255, 0.3);
    transform: translateY(-2px);
    text-decoration: none;
    color: white;
}

.footer-store-btn img {
    width: 24px;
    height: 24px;
    flex-shrink: 0;
}

.footer-store-btn .store-text {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    line-height: 1.2;
}

.footer-store-btn .store-text .small {
    font-size: 0.7rem;
    opacity: 0.9;
    font-weight: 400;
}

.footer-store-btn .store-text .large {
    font-size: 0.9rem;
    font-weight: 600;
}

/* QR Code Section */
.footer-qr-section {
    text-align: center;
    margin-left: 20px;
}

.footer-qr-label {
    color: white;
    font-size: 1rem;
    margin-bottom: 15px;
    font-weight: 500;
}

.footer-qr-code {
    background: white;
    padding: 15px;
    border-radius: 12px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
}

.footer-qr-code img {
    width: 120px;
    height: 120px;
    display: block;
}

/* App Icon Trigger */
.footer-app-icon {
    position: relative;
    cursor: pointer;
    transition: all 0.3s ease;
    margin-left: 20px;
    display: block;
}

.footer-app-icon.hidden {
    opacity: 0;
    pointer-events: none;
    transform: scale(0.8);
}

.footer-app-icon:hover {
    transform: scale(1.1);
}

.footer-app-icon.playing {
    transform: scale(1.1);
    filter: brightness(1.2);
}

.footer-app-icon img {
    width: 80px;
    height: 80px;
    border-radius: 16px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
    transition: all 0.3s ease;
}

.footer-app-icon::after {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    width: 20px;
    height: 20px;
    background: rgba(255, 255, 255, 0.9);
    border-radius: 50%;
    transform: translate(-50%, -50%);
    opacity: 0;
    transition: opacity 0.3s ease;
}

.footer-app-icon:hover::after {
    opacity: 1;
}

.footer-app-icon::before {
    content: '▶';
    position: absolute;
    top: 50%;
    left: 52%;
    transform: translate(-50%, -50%);
    color: #333;
    font-size: 10px;
    opacity: 0;
    transition: opacity 0.3s ease;
    z-index: 1;
}

.footer-app-icon:hover::before {
    opacity: 1;
}

/* Responsive Design */
@media (max-width: 768px) {
    .footer-content-wrapper {
        flex-direction: column;
        text-align: center;
        gap: 30px;
        justify-content: center;
        padding: 0 20px;
    }

    .footer-download-card {
        padding: 30px 20px;
        margin: 0;
        max-width: none;
        width: 100%;
        box-sizing: border-box;
    }

    .footer-download-card h2 {
        font-size: 2rem;
    }

    .footer-download-options {
        flex-direction: column;
        align-items: center;
        gap: 25px;
    }

    .footer-store-buttons {
        justify-content: center;
    }

    .footer-qr-section {
        margin-left: 0;
    }

    .footer-app-icon {
        margin-left: 0;
        display: none;
    }

    /* Hide video on mobile/tablet */
    .footer-video-background {
        display: none;
    }
}

@media (max-width: 480px) {
    .footer-download-section {
        padding: 40px 0px;
    }

    .footer-content-wrapper {
        padding: 0 15px;
    }

    .footer-store-buttons {
        /*flex-direction: column;*/
        width: 80%;
    }

    .footer-store-btn {
        width: 100%;
        justify-content: center;
    }

    .footer-qr-code img {
        width: 100px;
        height: 100px;
    }

    .footer-app-icon img {
        width: 60px;
        height: 60px;
    }

    .footer-download-card {
        max-width: none;
        margin: 0;
        width: 90%;
        box-sizing: border-box;
    }
}
</style>

<!-- HTML Section -->
<section class="footer-download-section">
    <!-- Video Background -->
    <div class="footer-video-background" id="footerVideoBackground">
        <video muted loop playsinline>
            <source src="https://ecocash.co.zw/wp-content/uploads/2025/07/Ecocash-App-Animation-BLUE.mp4" type="video/mp4">
        </video>
    </div>
    
    <!-- Fallback background -->
    <div class="footer-video-placeholder"></div>
    
    <!-- Flowing Light Streaks -->
    <div class="footer-light-streaks"></div>
    
    <!-- Dark Overlay -->
    <div class="footer-dark-overlay"></div>
    
    <!-- Main Content -->
    <div class="footer-content-wrapper">
        <div class="footer-download-card">
            <h2>Always On.<br>Always With You.</h2>
            <p>24/7 convenience from a brand you trust. <strong>Download</strong> the EcoCash app today or SCAN CODE to get started.</p>
            
            <div class="footer-download-options">
                <div class="footer-store-buttons">
                    <a href="https://apps.apple.com/us/app/ecocash-zimbabwe/id6478928861" class="footer-store-btn" target="_blank" rel="noopener">
                        <img src="https://ecocash.co.zw/wp-content/uploads/2025/07/EcoCash-Apple-Image-.png" alt="Apple App Store">
                        <div class="store-text">
                            <span class="small">Available on the</span>
                            <span class="large">App Store</span>
                        </div>
                    </a>
                    <a href="https://play.google.com/store/apps/details?id=com.ecocash&hl=en_ZA" class="footer-store-btn" target="_blank" rel="noopener">
                        <img src="https://ecocash.co.zw/wp-content/uploads/2025/07/EcoCash-Playstore-Image-.png" alt="Google Play Store">
                        <div class="store-text">
                            <span class="small">GET IT ON</span>
                            <span class="large">Google Play</span>
                        </div>
                    </a>
                </div>
                
                <div class="footer-qr-section">
                    <div class="footer-qr-label">Scan Me</div>
                    <div class="footer-qr-code">
                        <img src="https://ecocash.co.zw/wp-content/uploads/2026/01/QR.jpg" alt="QR Code to download EcoCash app">
                    </div>
                </div>
            </div>
        </div>
        
        <!-- App Icon Trigger -->
        <div class="footer-app-icon" onclick="toggleFooterVideo()">
            <img src="https://ecocash.co.zw/wp-content/uploads/2025/07/EcoCash-App-Image.png" alt="EcoCash App">
        </div>
    </div>
</section>

<!-- JavaScript -->
<script>
function toggleFooterVideo() {
    const videoBackground = document.getElementById('footerVideoBackground');
    const video = videoBackground.querySelector('video');
    const appIcon = document.querySelector('.footer-app-icon');
    
    if (video.paused) {
        video.play();
        videoBackground.classList.add('active');
        appIcon.classList.add('playing');
        appIcon.classList.add('hidden'); // Hide the button after clicking play
    } else {
        video.pause();
        videoBackground.classList.remove('active');
        appIcon.classList.remove('playing');
        appIcon.classList.remove('hidden'); // Show the button again if paused
    }
}

// Optional: Auto-hide video after some time
function autoHideVideo() {
    const videoBackground = document.getElementById('footerVideoBackground');
    const video = videoBackground.querySelector('video');
    const appIcon = document.querySelector('.footer-app-icon');
    
    setTimeout(() => {
        if (!video.paused) {
            video.pause();
            videoBackground.classList.remove('active');
            appIcon.classList.remove('playing');
        }
    }, 10000); // Hide after 10 seconds
}
</script>
		</div>
	</div>
</div></div></div></div><div class="vc_row-full-width vc_clearfix"></div><section id="Footer Middle" data-vc-full-width="true" data-vc-full-width-temp="true" data-vc-full-width-init="false" class="vc_section vc_custom_1752407413723 vc_section-has-fill"><div data-vc-full-width="true" data-vc-full-width-temp="true" data-vc-full-width-init="false" data-vc-stretch-content="true" class="vc_row wpb_row vc_row-fluid vc_row-no-padding"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner"><div class="wpb_wrapper"><div class="cz_gap clr " style="height: 50px"></div></div></div></div></div><div class="vc_row-full-width vc_clearfix"></div><div class="vc_row wpb_row vc_row-fluid middle-footer"><div class="wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner"><div class="wpb_wrapper"><div class="cz_gap clr  hide_on_mobile" style="height: 80px"></div><div class="cz_gap show_on_mobile clr" style="height: 0px"></div><a href="https://ecocash.co.zw/" title="EcoCash Zimbabwe" aria-label="EcoCash Zimbabwe"><div id="cz_90041" class="cz_90041 cz_image clr cz_image_no_fx center_on_mobile"><div class="" ><div class="cz_image_in"><div class="cz_main_image"><img width="225" height="76" src="https://ecocash.co.zw/wp-content/uploads/2025/07/EcoCash_logo.png" class="attachment-full" alt="" title="EcoCash_logo" decoding="async" /></div></div></div></div></a><div class="cz_gap clr " style="height: 20px"></div></div></div></div><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner"><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner"><div class="wpb_wrapper"><div id="cz_24535" class="cz_24535 cz_title clr cz_mobile_text_center cz_title_pos_inline"><div class="cz_title_content"><div class="cz_wpe_content"><h4><strong>About</strong></h4>
</div></div></div><div class="cz_gap clr " style="height: 30px"></div><div id="cz_61205" class="cz_61205 cz_title clr cz_mobile_text_center cz_title_pos_inline"><div class="cz_title_content"><div class="cz_wpe_content"><p><a href="https://ecocash.co.zw/about-us/">What is EcoCash?</a><br />
<a href="https://ecocash.co.zw/promotions/">Promotions</a><br />
<a href="https://ecocash.co.zw/tarriff-calculator/">Tarrifs</a><br />
<a href="https://ecocash.co.zw/news">News</a></p>
</div></div></div></div></div></div><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner"><div class="wpb_wrapper"><div id="cz_69583" class="cz_69583 cz_title clr cz_mobile_text_center cz_title_pos_inline"><div class="cz_title_content"><div class="cz_wpe_content"><h4><strong>Quick Links</strong></h4>
</div></div></div><div class="cz_gap clr " style="height: 30px"></div><div id="cz_102755" class="cz_102755 cz_title clr cz_mobile_text_center cz_title_pos_inline"><div class="cz_title_content"><div class="cz_wpe_content"><p><a href="https://ecocash.co.zw/download/">Download</a></p>
</div></div></div></div></div></div><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner"><div class="wpb_wrapper"><div id="cz_32438" class="cz_32438 cz_title clr cz_mobile_text_center cz_title_pos_inline"><div class="cz_title_content"><div class="cz_wpe_content"><h4><strong>Legal</strong></h4>
</div></div></div><div class="cz_gap clr " style="height: 30px"></div><div id="cz_95225" class="cz_95225 cz_title clr cz_mobile_text_center cz_title_pos_inline"><div class="cz_title_content"><div class="cz_wpe_content"><p><a href="https://ecocash.co.zw/terms-and-conditions/">Terms &amp; Conditions</a></p>
</div></div></div></div></div></div><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner"><div class="wpb_wrapper"><div id="cz_24288" class="cz_24288 cz_title clr cz_mobile_text_center cz_title_pos_inline"><div class="cz_title_content"><div class="cz_wpe_content"><h4><strong>Support</strong></h4>
</div></div></div><div class="cz_gap clr " style="height: 30px"></div><div id="cz_99533" class="cz_99533 cz_title clr cz_mobile_text_center cz_title_pos_inline"><div class="cz_title_content"><div class="cz_wpe_content"><p><a href="https://ecocash.co.zw/faqs/">FAQs</a><br />
<a href="https://ecocash.co.zw/contact-us/">Contact Us</a></p>
</div></div></div></div></div></div></div></div></div></div><div class="wpb_column vc_column_container vc_col-sm-2"><div class="vc_column-inner"><div class="wpb_wrapper"><div id="cz_87302" class="cz_87302 cz_social_icons cz_social clr tal center_on_mobile"><a href="https://www.facebook.com/ecocashzim/" class="cz-facebook"title="Facebook" aria-label="Facebook"><i class="fa fa-facebook"></i></a><a href="https://x.com/EcoCashZW" class="cz-x-twitter"title="X" aria-label="X"><i class="fab fa-x-twitter"></i></a><a href="https://www.instagram.com/ecocash_zimbabwe" class="cz-instagram"title="Instagram" aria-label="Instagram"><i class="fab fa-instagram"></i></a><a href="https://www.youtube.com/@ecocashzw" class="cz-192-youtube"title="Youtube" aria-label="Youtube"><i class="fa czico-192-youtube"></i></a></div></div></div></div></div><div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-12 vc_hidden-lg vc_hidden-md vc_hidden-xs"><div class="vc_column-inner"><div class="wpb_wrapper"><a href="https://ecocash.co.zw/" title="EcoCash Zimbabwe" aria-label="EcoCash Zimbabwe"><div id="cz_28382" class="cz_28382 cz_image clr cz_image_no_fx center_on_mobile"><div class="" ><div class="cz_image_in"><div class="cz_main_image"><img width="225" height="76" src="https://ecocash.co.zw/wp-content/uploads/2025/07/EcoCash_logo.png" class="attachment-full" alt="" title="EcoCash_logo" decoding="async" /></div></div></div></div></a><div class="cz_gap clr " style="height: 10px"></div><div class="cz_gap clr " style="height: 10px"></div><div class="cz_gap clr " style="height: 20px"></div></div></div></div></div><div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-12 vc_hidden-lg vc_hidden-md vc_hidden-xs"><div class="vc_column-inner"><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner"><div class="wpb_wrapper"><div id="cz_98208" class="cz_98208 cz_title clr cz_mobile_text_center cz_title_pos_inline tac"><div class="cz_title_content"><div class="cz_wpe_content"><h4 style="text-align: center;"><strong>About</strong></h4>
</div></div></div><div class="cz_gap clr " style="height: 30px"></div><div id="cz_100434" class="cz_100434 cz_title clr cz_mobile_text_center cz_title_pos_inline tac"><div class="cz_title_content"><div class="cz_wpe_content"><p style="text-align: center;"><a href="https://ecocash.co.zw/about-us/">What is EcoCash?</a><br />
<a href="https://ecocash.co.zw/promotions/">Promotions</a><br />
<a href="https://ecocash.co.zw/tarriff-calculator/">Tarrifs</a><br />
<a href="https://ecocash.co.zw/news">News</a></p>
</div></div></div></div></div></div><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner"><div class="wpb_wrapper"><div id="cz_59011" class="cz_59011 cz_title clr cz_mobile_text_center cz_title_pos_inline tac"><div class="cz_title_content"><div class="cz_wpe_content"><h4 style="text-align: center;"><strong>Quick Links</strong></h4>
</div></div></div><div class="cz_gap clr " style="height: 30px"></div><div id="cz_21234" class="cz_21234 cz_title clr cz_mobile_text_center cz_title_pos_inline tac"><div class="cz_title_content"><div class="cz_wpe_content"><p style="text-align: center;"><a href="https://ecocash.co.zw/download/">Download</a></p>
</div></div></div></div></div></div><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner"><div class="wpb_wrapper"><div id="cz_106120" class="cz_106120 cz_title clr cz_mobile_text_center cz_title_pos_inline tac"><div class="cz_title_content"><div class="cz_wpe_content"><h4 style="text-align: center;"><strong>Legal</strong></h4>
</div></div></div><div class="cz_gap clr " style="height: 30px"></div><div id="cz_22107" class="cz_22107 cz_title clr cz_mobile_text_center cz_title_pos_inline tac"><div class="cz_title_content"><div class="cz_wpe_content"><p style="text-align: center;"><a href="https://ecocash.co.zw/terms-and-conditions/">Terms &amp; Conditions</a></p>
</div></div></div></div></div></div><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner"><div class="wpb_wrapper"><div id="cz_67969" class="cz_67969 cz_title clr cz_mobile_text_center cz_title_pos_inline tac"><div class="cz_title_content"><div class="cz_wpe_content"><h4 style="text-align: center;"><strong>Support</strong></h4>
</div></div></div><div class="cz_gap clr " style="height: 30px"></div><div id="cz_72318" class="cz_72318 cz_title clr cz_mobile_text_center cz_title_pos_inline tac"><div class="cz_title_content"><div class="cz_wpe_content"><p style="text-align: center;"><a href="https://ecocash.co.zw/faqs/">FAQs</a><br />
<a href="https://ecocash.co.zw/contact-us/">Contact Us</a></p>
</div></div></div></div></div></div></div></div></div></div></div><div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-12 vc_hidden-lg vc_hidden-md vc_hidden-xs"><div class="vc_column-inner"><div class="wpb_wrapper"><div class="cz_gap clr " style="height: 30px"></div><div id="cz_91276" class="cz_91276 cz_social_icons cz_social clr tac center_on_mobile"><a href="https://www.facebook.com/ecocashzim/" class="cz-facebook"title="Facebook" aria-label="Facebook"><i class="fa fa-facebook"></i></a><a href="https://x.com/EcoCashZW" class="cz-x-twitter"title="X" aria-label="X"><i class="fab fa-x-twitter"></i></a><a href="https://www.instagram.com/ecocash_zimbabwe" class="cz-instagram"title="Instagram" aria-label="Instagram"><i class="fab fa-instagram"></i></a><a href="https://www.youtube.com/@ecocashzw" class="cz-192-youtube"title="Youtube" aria-label="Youtube"><i class="fa czico-192-youtube"></i></a></div></div></div></div></div></section><div class="vc_row-full-width vc_clearfix"></div><section id="Footer Bottom" data-vc-full-width="true" data-vc-full-width-temp="true" data-vc-full-width-init="false" class="vc_section vc_custom_1752408341594 vc_section-has-fill"><div class="vc_row wpb_row vc_row-fluid vc_custom_1752408351570 vc_row-has-fill"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner"><div class="wpb_wrapper"><div class="cz_gap clr " style="height: 40px"></div><div id="cz_67219" class="cz_67219 cz_title clr cz_title_pos_inline tac"><div class="cz_title_content"><div class="cz_wpe_content"><p style="text-align: center;">Copyright © 2026 EcoCash Zimbabwe. All rights reserved. <a href="https://ecocash.co.zw/terms-and-conditions/">Terms and conditions</a> apply.<br />
Web design by <a href="https://dicomm.co.zw" target="_blank" rel="noopener">Dicomm McCann</a></p>
</div></div></div><div class="cz_gap clr " style="height: 20px"></div></div></div></div></div></section><div class="vc_row-full-width vc_clearfix"></div></div></div></footer></div></div><script type="speculationrules">
{"prefetch":[{"source":"document","where":{"and":[{"href_matches":"/*"},{"not":{"href_matches":["/wp-*.php","/wp-admin/*","/wp-content/uploads/*","/wp-content/*","/wp-content/plugins/*","/wp-content/themes/ecocash-child/*","/wp-content/themes/ecocash/*","/*\\?(.+)"]}},{"not":{"selector_matches":"a[rel~=\"nofollow\"]"}},{"not":{"selector_matches":".no-prefetch, .no-prefetch a"}}]},"eagerness":"conservative"}]}
</script>
<div class="cz_fixed_top_border"></div><div class="cz_fixed_bottom_border"></div><script src="https://ecocash.co.zw/wp-includes/js/dist/hooks.min.js?ver=dd5603f07f9220ed27f1" id="wp-hooks-js"></script>
<script src="https://ecocash.co.zw/wp-includes/js/dist/i18n.min.js?ver=c26c3dc7bed366793375" id="wp-i18n-js"></script>
<script id="wp-i18n-js-after">
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
//# sourceURL=wp-i18n-js-after
</script>
<script src="https://ecocash.co.zw/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=6.1" id="swv-js"></script>
<script id="contact-form-7-js-before">
var wpcf7 = {
    "api": {
        "root": "https:\/\/ecocash.co.zw\/wp-json\/",
        "namespace": "contact-form-7\/v1"
    }
};
//# sourceURL=contact-form-7-js-before
</script>
<script src="https://ecocash.co.zw/wp-content/plugins/contact-form-7/includes/js/index.js?ver=6.1" id="contact-form-7-js"></script>
<script id="ecocash-calculator-script-js-extra">
var ecocash_ajax = {"ajax_url":"https://ecocash.co.zw/wp-admin/admin-ajax.php","nonce":"72082fcc43"};
//# sourceURL=ecocash-calculator-script-js-extra
</script>
<script src="https://ecocash.co.zw/wp-content/plugins/tariff%20calc%20final/assets/js/script.js?ver=2.0" id="ecocash-calculator-script-js"></script>
<script src="https://ecocash.co.zw/wp-content/themes/ecocash/assets/js/codevz-menu.min.js?ver=4.9.16" id="codevz-menu-js"></script>
<script src="https://ecocash.co.zw/wp-content/themes/ecocash/assets/js/custom.js?ver=4.9.16" id="codevz-js"></script>
<script src="https://ecocash.co.zw/wp-content/plugins/quadmenu/assets/frontend/pscrollbar/perfect-scrollbar.jquery.min.js?ver=3.2.4" id="pscrollbar-js"></script>
<script src="https://ecocash.co.zw/wp-content/plugins/quadmenu/assets/frontend/owlcarousel/owl.carousel.min.js?ver=3.2.4" id="owlcarousel-js"></script>
<script src="https://ecocash.co.zw/wp-includes/js/hoverIntent.min.js?ver=1.10.2" id="hoverIntent-js"></script>
<script id="quadmenu-js-extra">
var quadmenu = {"ajaxurl":"https://ecocash.co.zw/wp-admin/admin-ajax.php","gutter":"30"};
//# sourceURL=quadmenu-js-extra
</script>
<script src="https://ecocash.co.zw/wp-content/plugins/quadmenu/build/frontend/index.js?ver=64a0778cf68e89eed44f" id="quadmenu-js"></script>
<script src="https://ecocash.co.zw/wp-content/plugins/codevz-plus/assets/js/codevzplus.js?ver=4.9.16" id="codevz-plus-js"></script>
<script id="chaty-front-end-js-extra">
var chaty_settings = {"ajax_url":"https://ecocash.co.zw/wp-admin/admin-ajax.php","analytics":"0","capture_analytics":"1","token":"4b53e4ccb5","chaty_widgets":[{"id":0,"identifier":0,"settings":{"cta_type":"simple-view","cta_body":"","cta_head":"","cta_head_bg_color":"","cta_head_text_color":"","show_close_button":1,"position":"right","custom_position":1,"bottom_spacing":"25","side_spacing":"25","icon_view":"vertical","default_state":"click","cta_text":"\u003Cp\u003ESay Hi to Thembi&nbsp;\u003C/p\u003E","cta_text_color":"#333333","cta_bg_color":"#ffffff","show_cta":"first_click","is_pending_mesg_enabled":"off","pending_mesg_count":"1","pending_mesg_count_color":"#ffffff","pending_mesg_count_bgcolor":"#dd0000","widget_icon":"chat-base","widget_icon_url":"","font_family":"-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen-Sans,Ubuntu,Cantarell,Helvetica Neue,sans-serif","widget_size":"54","custom_widget_size":"54","is_google_analytics_enabled":0,"close_text":"Hide","widget_color":"#A886CD","widget_icon_color":"#ffffff","widget_rgb_color":"168,134,205","has_custom_css":0,"custom_css":"","widget_token":"42ce172203","widget_index":"","attention_effect":""},"triggers":{"has_time_delay":1,"time_delay":"0","exit_intent":0,"has_display_after_page_scroll":0,"display_after_page_scroll":"0","auto_hide_widget":0,"hide_after":0,"show_on_pages_rules":[],"time_diff":0,"has_date_scheduling_rules":0,"date_scheduling_rules":{"start_date_time":"","end_date_time":""},"date_scheduling_rules_timezone":0,"day_hours_scheduling_rules_timezone":0,"has_day_hours_scheduling_rules":[],"day_hours_scheduling_rules":[],"day_time_diff":0,"show_on_direct_visit":0,"show_on_referrer_social_network":0,"show_on_referrer_search_engines":0,"show_on_referrer_google_ads":0,"show_on_referrer_urls":[],"has_show_on_specific_referrer_urls":0,"has_traffic_source":0,"has_countries":0,"countries":[],"has_target_rules":0},"channels":[{"channel":"Whatsapp","value":"263777222150","hover_text":"WhatsApp","chatway_position":"","svg_icon":"\u003Csvg width=\"39\" height=\"39\" viewBox=\"0 0 39 39\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\"\u003E\u003Ccircle class=\"color-element\" cx=\"19.4395\" cy=\"19.4395\" r=\"19.4395\" fill=\"#49E670\"/\u003E\u003Cpath d=\"M12.9821 10.1115C12.7029 10.7767 11.5862 11.442 10.7486 11.575C10.1902 11.7081 9.35269 11.8411 6.84003 10.7767C3.48981 9.44628 1.39593 6.25317 1.25634 6.12012C1.11674 5.85403 2.13001e-06 4.39053 2.13001e-06 2.92702C2.13001e-06 1.46351 0.83755 0.665231 1.11673 0.399139C1.39592 0.133046 1.8147 1.01506e-06 2.23348 1.01506e-06C2.37307 1.01506e-06 2.51267 1.01506e-06 2.65226 1.01506e-06C2.93144 1.01506e-06 3.21063 -2.02219e-06 3.35022 0.532183C3.62941 1.19741 4.32736 2.66092 4.32736 2.79397C4.46696 2.92702 4.46696 3.19311 4.32736 3.32616C4.18777 3.59225 4.18777 3.59224 3.90858 3.85834C3.76899 3.99138 3.6294 4.12443 3.48981 4.39052C3.35022 4.52357 3.21063 4.78966 3.35022 5.05576C3.48981 5.32185 4.18777 6.38622 5.16491 7.18449C6.42125 8.24886 7.39839 8.51496 7.81717 8.78105C8.09636 8.91409 8.37554 8.9141 8.65472 8.648C8.93391 8.38191 9.21309 7.98277 9.49228 7.58363C9.77146 7.31754 10.0507 7.1845 10.3298 7.31754C10.609 7.45059 12.2841 8.11582 12.5633 8.38191C12.8425 8.51496 13.1217 8.648 13.1217 8.78105C13.1217 8.78105 13.1217 9.44628 12.9821 10.1115Z\" transform=\"translate(12.9597 12.9597)\" fill=\"#FAFAFA\"/\u003E\u003Cpath d=\"M0.196998 23.295L0.131434 23.4862L0.323216 23.4223L5.52771 21.6875C7.4273 22.8471 9.47325 23.4274 11.6637 23.4274C18.134 23.4274 23.4274 18.134 23.4274 11.6637C23.4274 5.19344 18.134 -0.1 11.6637 -0.1C5.19344 -0.1 -0.1 5.19344 -0.1 11.6637C-0.1 13.9996 0.624492 16.3352 1.93021 18.2398L0.196998 23.295ZM5.87658 19.8847L5.84025 19.8665L5.80154 19.8788L2.78138 20.8398L3.73978 17.9646L3.75932 17.906L3.71562 17.8623L3.43104 17.5777C2.27704 15.8437 1.55796 13.8245 1.55796 11.6637C1.55796 6.03288 6.03288 1.55796 11.6637 1.55796C17.2945 1.55796 21.7695 6.03288 21.7695 11.6637C21.7695 17.2945 17.2945 21.7695 11.6637 21.7695C9.64222 21.7695 7.76778 21.1921 6.18227 20.039L6.17557 20.0342L6.16817 20.0305L5.87658 19.8847Z\" transform=\"translate(7.7758 7.77582)\" fill=\"white\" stroke=\"white\" stroke-width=\"0.2\"/\u003E\u003C/svg\u003E","is_desktop":1,"is_mobile":1,"icon_color":"#49E670","icon_rgb_color":"73,230,112","channel_type":"Whatsapp","custom_image_url":"","order":"","pre_set_message":"","is_use_web_version":"1","is_open_new_tab":"1","is_default_open":"0","has_welcome_message":"0","emoji_picker":"1","input_placeholder":"Write your message...","chat_welcome_message":"\u003Cp\u003EHow can I help you? :)\u003C/p\u003E","wp_popup_headline":"Let&#039;s chat on WhatsApp","wp_popup_nickname":"","wp_popup_profile":"","wp_popup_head_bg_color":"#4AA485","qr_code_image_url":"","mail_subject":"","channel_account_type":"personal","contact_form_settings":[],"contact_fields":[],"url":"https://web.whatsapp.com/send?phone=263777222150","mobile_target":"","desktop_target":"_blank","target":"_blank","is_agent":0,"agent_data":[],"header_text":"","header_sub_text":"","header_bg_color":"","header_text_color":"","widget_token":"42ce172203","widget_index":"","click_event":"","viber_url":""}]}],"data_analytics_settings":"off","lang":{"whatsapp_label":"WhatsApp Message","hide_whatsapp_form":"Hide WhatsApp Form","emoji_picker":"Show Emojis"},"has_chatway":""};
//# sourceURL=chaty-front-end-js-extra
</script>
<script defer src="https://ecocash.co.zw/wp-content/plugins/chaty/js/cht-front-script.min.js?ver=3.4.61756141129" id="chaty-front-end-js"></script>
<script src="https://ecocash.co.zw/wp-content/plugins/google-site-kit/dist/assets/js/googlesitekit-events-provider-contact-form-7-84e9a1056bc4922b7cbd.js" id="googlesitekit-events-provider-contact-form-7-js" defer></script>
<script src="https://ecocash.co.zw/wp-includes/js/jquery/ui/core.min.js?ver=1.13.3" id="jquery-ui-core-js"></script>
<script id="popup-maker-site-js-extra">
var pum_vars = {"version":"1.20.5","pm_dir_url":"https://ecocash.co.zw/wp-content/plugins/popup-maker/","ajaxurl":"https://ecocash.co.zw/wp-admin/admin-ajax.php","restapi":"https://ecocash.co.zw/wp-json/pum/v1","rest_nonce":null,"default_theme":"1871","debug_mode":"","disable_tracking":"","home_url":"/","message_position":"top","core_sub_forms_enabled":"1","popups":[],"cookie_domain":"","analytics_route":"analytics","analytics_api":"https://ecocash.co.zw/wp-json/pum/v1"};
var pum_sub_vars = {"ajaxurl":"https://ecocash.co.zw/wp-admin/admin-ajax.php","message_position":"top"};
var pum_popups = [];
//# sourceURL=popup-maker-site-js-extra
</script>
<script src="https://ecocash.co.zw/wp-content/plugins/popup-maker/assets/js/site.min.js?defer&amp;ver=1.20.5" id="popup-maker-site-js"></script>
<script src="https://ecocash.co.zw/wp-content/plugins/google-site-kit/dist/assets/js/googlesitekit-events-provider-popup-maker-38c8b97d166ddb055277.js" id="googlesitekit-events-provider-popup-maker-js" defer></script>
<script src="https://ecocash.co.zw/wp-content/themes/ecocash/assets/js/search.js?ver=6.9.1" id="codevz-search-js"></script>
<script src="https://ecocash.co.zw/wp-content/plugins/js_composer/assets/js/dist/js_composer_front.min.js?ver=8.5" id="wpb_composer_front_js-js"></script>
<script src="https://ecocash.co.zw/wp-content/plugins/codevz-plus/wpbakery/assets/js/title.js?ver=4.9.16" id="cz_title-js"></script>
<script src="https://ecocash.co.zw/wp-content/plugins/codevz-plus/wpbakery/assets/js/image.js?ver=4.9.16" id="cz_image-js"></script>
<script id="wp-emoji-settings" type="application/json">
{"baseUrl":"https://s.w.org/images/core/emoji/17.0.2/72x72/","ext":".png","svgUrl":"https://s.w.org/images/core/emoji/17.0.2/svg/","svgExt":".svg","source":{"concatemoji":"https://ecocash.co.zw/wp-includes/js/wp-emoji-release.min.js?ver=6.9.1"}}
</script>
<script type="module">
/*! This file is auto-generated */
const a=JSON.parse(document.getElementById("wp-emoji-settings").textContent),o=(window._wpemojiSettings=a,"wpEmojiSettingsSupports"),s=["flag","emoji"];function i(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function c(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0);const a=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);return t.every((e,t)=>e===a[t])}function p(e,t){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var n=e.getImageData(16,16,1,1);for(let e=0;e<n.data.length;e++)if(0!==n.data[e])return!1;return!0}function u(e,t,n,a){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\udde8\ud83c\uddf6","\ud83c\udde8\u200b\ud83c\uddf6")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!a(e,"\ud83e\u1fac8")}return!1}function f(e,t,n,a){let r;const o=(r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):document.createElement("canvas")).getContext("2d",{willReadFrequently:!0}),s=(o.textBaseline="top",o.font="600 32px Arial",{});return e.forEach(e=>{s[e]=t(o,e,n,a)}),s}function r(e){var t=document.createElement("script");t.src=e,t.defer=!0,document.head.appendChild(t)}a.supports={everything:!0,everythingExceptFlag:!0},new Promise(t=>{let n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),c.toString(),p.toString()].join(",")+"));",a=new Blob([e],{type:"text/javascript"});const r=new Worker(URL.createObjectURL(a),{name:"wpTestEmojiSupports"});return void(r.onmessage=e=>{i(n=e.data),r.terminate(),t(n)})}catch(e){}i(n=f(s,u,c,p))}t(n)}).then(e=>{for(const n in e)a.supports[n]=e[n],a.supports.everything=a.supports.everything&&a.supports[n],"flag"!==n&&(a.supports.everythingExceptFlag=a.supports.everythingExceptFlag&&a.supports[n]);var t;a.supports.everythingExceptFlag=a.supports.everythingExceptFlag&&!a.supports.flag,a.supports.everything||((t=a.source||{}).concatemoji?r(t.concatemoji):t.wpemoji&&t.twemoji&&(r(t.twemoji),r(t.wpemoji)))});
//# sourceURL=https://ecocash.co.zw/wp-includes/js/wp-emoji-loader.min.js
</script>
<script></script><script>(function(){function c(){var b=a.contentDocument||a.contentWindow.document;if(b){var d=b.createElement('script');d.innerHTML="window.__CF$cv$params={r:'9ca184da6b168f05',t:'MTc3MDQ1Mjk2MS4wMDAwMDA='};var a=document.createElement('script');a.nonce='';a.src='/cdn-cgi/challenge-platform/scripts/jsd/main.js';document.getElementsByTagName('head')[0].appendChild(a);";b.getElementsByTagName('head')[0].appendChild(d)}}if(document.body){var a=document.createElement('iframe');a.height=1;a.width=1;a.style.position='absolute';a.style.top=0;a.style.left=0;a.style.border='none';a.style.visibility='hidden';document.body.appendChild(a);if('loading'!==document.readyState)c();else if(window.addEventListener)document.addEventListener('DOMContentLoaded',c);else{var e=document.onreadystatechange||function(){};document.onreadystatechange=function(b){e(b);'loading'!==document.readyState&&(document.onreadystatechange=e,c())}}}})();</script></body></html>